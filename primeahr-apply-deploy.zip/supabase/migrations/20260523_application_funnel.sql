-- ============================================================================
-- PrimeaHR — Application Funnel Migration
-- Adds hire-to-onboard pipeline: applications, AI parsing, semantic search,
-- AI fit scoring, document uploads, and audit trail.
-- ============================================================================

-- Enable pgvector for semantic search across resumes and requisitions
CREATE EXTENSION IF NOT EXISTS vector;

-- ============================================================================
-- 1. APPLICATIONS — the core record for someone moving through the funnel
-- ============================================================================
CREATE TABLE IF NOT EXISTS applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Linkage
  candidate_id UUID REFERENCES candidates(id) ON DELETE SET NULL,
  requisition_id UUID REFERENCES requisitions(id) ON DELETE SET NULL,
  role_slug TEXT NOT NULL, -- e.g. 'dsp', 'support-planner', 'rn'

  -- State machine
  status TEXT NOT NULL DEFAULT 'in_progress',
    -- in_progress | submitted | screening | offered | accepted | declined | rejected | hired
  current_step INTEGER NOT NULL DEFAULT 1,
  total_steps INTEGER NOT NULL DEFAULT 8,

  -- Resume
  resume_storage_path TEXT,
  resume_filename TEXT,
  resume_parsed JSONB, -- structured output from Claude

  -- Form data (denormalized for save-as-you-go)
  form_data JSONB NOT NULL DEFAULT '{}'::jsonb,

  -- AI summary & scoring (cached against the candidate's primary requisition)
  ai_summary TEXT,
  ai_fit_score INTEGER, -- 0-100
  ai_fit_reasoning TEXT,
  ai_strengths JSONB,
  ai_gaps JSONB,
  ai_scored_at TIMESTAMPTZ,

  -- Save-and-resume magic link
  resume_token TEXT UNIQUE,
  resume_token_expires_at TIMESTAMPTZ,

  -- Signing
  signature_data TEXT, -- base64 signature image
  signed_at TIMESTAMPTZ,
  signed_ip INET,
  signed_user_agent TEXT,

  -- Submission
  submitted_at TIMESTAMPTZ,

  -- Audit
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_applications_candidate ON applications(candidate_id);
CREATE INDEX IF NOT EXISTS idx_applications_requisition ON applications(requisition_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_applications_role_slug ON applications(role_slug);
CREATE INDEX IF NOT EXISTS idx_applications_resume_token ON applications(resume_token);
CREATE INDEX IF NOT EXISTS idx_applications_submitted_at ON applications(submitted_at DESC);

-- ============================================================================
-- 2. APPLICATION_DOCUMENTS — files uploaded during application
-- ============================================================================
CREATE TABLE IF NOT EXISTS application_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE,

  doc_type TEXT NOT NULL,
    -- 'resume' | 'drivers_license' | 'ssn_card' | 'bachelors_diploma' | 'college_transcript'
    -- | 'diploma_or_ged' | 'auto_insurance' | 'professional_references'
    -- | 'pct_certification' | 'case_management_cert' | 'additional_certifications' | 'other'
  storage_path TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_size_bytes INTEGER,
  mime_type TEXT,

  -- OCR extraction
  ocr_status TEXT DEFAULT 'pending', -- pending | processing | complete | failed | skipped
  ocr_provider TEXT, -- 'mindee' | 'claude_vision' | 'textract'
  ocr_extracted JSONB,
  ocr_confidence NUMERIC(3,2),
  ocr_processed_at TIMESTAMPTZ,

  -- Detected metadata (e.g. license expiration)
  expires_at DATE,
  document_number TEXT, -- masked or full depending on doc type

  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_app_docs_application ON application_documents(application_id);
CREATE INDEX IF NOT EXISTS idx_app_docs_type ON application_documents(doc_type);
CREATE INDEX IF NOT EXISTS idx_app_docs_expires ON application_documents(expires_at);

-- ============================================================================
-- 3. APPLICATION_EVENTS — audit trail for the candidate journey
-- ============================================================================
CREATE TABLE IF NOT EXISTS application_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE,

  event_type TEXT NOT NULL,
    -- 'created' | 'resume_uploaded' | 'resume_parsed' | 'step_advanced'
    -- | 'document_uploaded' | 'ocr_complete' | 'ai_scored' | 'signed'
    -- | 'submitted' | 'stage_changed' | 'offer_sent' | 'offer_signed'
  actor TEXT, -- 'candidate' | 'system' | 'ai' | user_id
  metadata JSONB DEFAULT '{}'::jsonb,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_app_events_application ON application_events(application_id);
CREATE INDEX IF NOT EXISTS idx_app_events_type ON application_events(event_type);
CREATE INDEX IF NOT EXISTS idx_app_events_created ON application_events(created_at DESC);

-- ============================================================================
-- 4. CANDIDATE_EMBEDDINGS — pgvector for semantic search across resumes
-- ============================================================================
CREATE TABLE IF NOT EXISTS candidate_embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  application_id UUID REFERENCES applications(id) ON DELETE CASCADE,

  source TEXT NOT NULL, -- 'resume_full' | 'resume_summary' | 'skills' | 'experience'
  content_preview TEXT, -- first ~500 chars for debugging
  embedding VECTOR(1536), -- text-embedding-3-small dimensions; adjust if using different model

  model TEXT NOT NULL DEFAULT 'text-embedding-3-small',
  token_count INTEGER,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_candidate_embeddings_candidate ON candidate_embeddings(candidate_id);
CREATE INDEX IF NOT EXISTS idx_candidate_embeddings_source ON candidate_embeddings(source);

-- HNSW index for fast cosine similarity search
CREATE INDEX IF NOT EXISTS idx_candidate_embeddings_vector
  ON candidate_embeddings
  USING hnsw (embedding vector_cosine_ops);

-- ============================================================================
-- 5. REQUISITION_EMBEDDINGS — embed open jobs for candidate matching
-- ============================================================================
CREATE TABLE IF NOT EXISTS requisition_embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requisition_id UUID NOT NULL REFERENCES requisitions(id) ON DELETE CASCADE,

  source TEXT NOT NULL DEFAULT 'full_description',
  embedding VECTOR(1536),

  model TEXT NOT NULL DEFAULT 'text-embedding-3-small',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_req_embeddings_requisition ON requisition_embeddings(requisition_id);
CREATE INDEX IF NOT EXISTS idx_req_embeddings_vector
  ON requisition_embeddings
  USING hnsw (embedding vector_cosine_ops);

-- ============================================================================
-- 6. CANDIDATE_SCORES — AI fit scores per candidate × requisition
-- ============================================================================
CREATE TABLE IF NOT EXISTS candidate_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  requisition_id UUID NOT NULL REFERENCES requisitions(id) ON DELETE CASCADE,

  fit_score INTEGER NOT NULL, -- 0-100
  semantic_score NUMERIC(4,3), -- raw cosine similarity 0-1
  reasoning TEXT,
  strengths JSONB,
  gaps JSONB,
  recommended_action TEXT, -- 'fast_track' | 'standard_review' | 'screen_first' | 'pass'

  model TEXT NOT NULL DEFAULT 'claude-sonnet-4',
  prompt_version TEXT,

  scored_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(candidate_id, requisition_id)
);

CREATE INDEX IF NOT EXISTS idx_candidate_scores_candidate ON candidate_scores(candidate_id);
CREATE INDEX IF NOT EXISTS idx_candidate_scores_requisition ON candidate_scores(requisition_id);
CREATE INDEX IF NOT EXISTS idx_candidate_scores_fit ON candidate_scores(fit_score DESC);

-- ============================================================================
-- 7. ROLE_TEMPLATES — public-facing role definitions for the apply page
-- ============================================================================
CREATE TABLE IF NOT EXISTS role_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL, -- 'dsp', 'support-planner', etc.

  display_name TEXT NOT NULL,
  short_description TEXT,
  long_description TEXT,
  responsibilities JSONB, -- array of strings
  requirements JSONB,     -- array of strings
  nice_to_haves JSONB,    -- array of strings

  pay_range_min NUMERIC(10,2),
  pay_range_max NUMERIC(10,2),
  pay_frequency TEXT DEFAULT 'hourly', -- 'hourly' | 'salary'

  -- What docs do we need from this role at apply time?
  required_documents JSONB DEFAULT '[]'::jsonb, -- e.g. ['drivers_license', 'bachelors_diploma']
  optional_documents JSONB DEFAULT '[]'::jsonb,

  -- Onboarding kit (drives auto-generation of tasks after offer signed)
  onboarding_packet JSONB DEFAULT '[]'::jsonb,

  active BOOLEAN NOT NULL DEFAULT true,
  is_public BOOLEAN NOT NULL DEFAULT true,
  hero_image_url TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_role_templates_slug ON role_templates(slug);
CREATE INDEX IF NOT EXISTS idx_role_templates_active ON role_templates(active, is_public);

-- ============================================================================
-- 8. UPDATED_AT TRIGGERS
-- ============================================================================
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_applications_updated ON applications;
CREATE TRIGGER trg_applications_updated
  BEFORE UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_role_templates_updated ON role_templates;
CREATE TRIGGER trg_role_templates_updated
  BEFORE UPDATE ON role_templates
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_req_embeddings_updated ON requisition_embeddings;
CREATE TRIGGER trg_req_embeddings_updated
  BEFORE UPDATE ON requisition_embeddings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ============================================================================
-- 9. ROW LEVEL SECURITY
-- ============================================================================
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE application_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE application_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidate_embeddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE requisition_embeddings ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidate_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_templates ENABLE ROW LEVEL SECURITY;

-- Public can read active role templates (the apply page renders these)
DROP POLICY IF EXISTS "public read active roles" ON role_templates;
CREATE POLICY "public read active roles" ON role_templates
  FOR SELECT TO anon, authenticated
  USING (active = true AND is_public = true);

-- Public (anon) can INSERT a new application via the apply page
DROP POLICY IF EXISTS "anon create application" ON applications;
CREATE POLICY "anon create application" ON applications
  FOR INSERT TO anon
  WITH CHECK (status = 'in_progress');

-- Public can read/update their own application via resume_token
-- (We enforce this via the API layer using the token, not RLS — RLS open here.)
DROP POLICY IF EXISTS "anon read own application" ON applications;
CREATE POLICY "anon read own application" ON applications
  FOR SELECT TO anon
  USING (resume_token IS NOT NULL);

DROP POLICY IF EXISTS "anon update own application" ON applications;
CREATE POLICY "anon update own application" ON applications
  FOR UPDATE TO anon
  USING (resume_token IS NOT NULL AND status IN ('in_progress', 'submitted'));

-- Staff (authenticated) can read everything
DROP POLICY IF EXISTS "staff read applications" ON applications;
CREATE POLICY "staff read applications" ON applications
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "staff update applications" ON applications;
CREATE POLICY "staff update applications" ON applications
  FOR UPDATE TO authenticated USING (true);

DROP POLICY IF EXISTS "staff read app docs" ON application_documents;
CREATE POLICY "staff read app docs" ON application_documents
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "anon insert app doc" ON application_documents;
CREATE POLICY "anon insert app doc" ON application_documents
  FOR INSERT TO anon
  WITH CHECK (true);

DROP POLICY IF EXISTS "staff read events" ON application_events;
CREATE POLICY "staff read events" ON application_events
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "anon insert events" ON application_events;
CREATE POLICY "anon insert events" ON application_events
  FOR INSERT TO anon
  WITH CHECK (true);

DROP POLICY IF EXISTS "staff read embeddings" ON candidate_embeddings;
CREATE POLICY "staff read embeddings" ON candidate_embeddings
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "staff read req embeddings" ON requisition_embeddings;
CREATE POLICY "staff read req embeddings" ON requisition_embeddings
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "staff read scores" ON candidate_scores;
CREATE POLICY "staff read scores" ON candidate_scores
  FOR SELECT TO authenticated USING (true);

-- ============================================================================
-- 10. STORAGE BUCKETS
-- ============================================================================
-- Run separately if not already present:
--   INSERT INTO storage.buckets (id, name, public) VALUES
--     ('applications', 'applications', false),
--     ('resumes', 'resumes', false);
--
-- And these policies (paste in Supabase Studio → Storage → Policies):
--   - allow anon INSERT into 'applications/{appId}/*'
--   - allow authenticated SELECT on 'applications/*'

-- ============================================================================
-- 11. SEED — see the addendum migration 20260524_real_blh_roles.sql for the
-- full BLH role lineup (Support Planner, CCS, supervisors, admin, HR, etc.)
-- ============================================================================
-- This migration sets up the schema; the addendum populates it with reality.
