-- ============================================================================
-- PrimeaHR — Application Funnel ADDENDUM
-- Replaces the placeholder seed roles (dsp, support-planner, rn) with the real
-- BLH role lineup based on the ClearCompany audit.
--
-- BLH is a Maryland case management and care coordination agency. It does NOT
-- provide direct care. The two flagship roles are:
--   - Support Planner (~90 employees) — Community First Choice Department
--   - Coordinator of Community Services / CCS (~15-20) — DDA Department
-- ============================================================================

-- ============================================================================
-- 1. Add is_evergreen column (always-open requisitions like SP and CCS)
-- ============================================================================
ALTER TABLE role_templates
  ADD COLUMN IF NOT EXISTS is_evergreen BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE role_templates
  ADD COLUMN IF NOT EXISTS department TEXT;

ALTER TABLE role_templates
  ADD COLUMN IF NOT EXISTS career_level TEXT;  -- 'entry' | 'mid' | 'senior' | 'lead' | 'manager' | 'director'

CREATE INDEX IF NOT EXISTS idx_role_templates_evergreen ON role_templates(is_evergreen) WHERE active = true;

-- ============================================================================
-- 2. Remove the placeholder seed roles
-- ============================================================================
DELETE FROM role_templates WHERE slug IN ('dsp', 'support-planner', 'rn');

-- ============================================================================
-- 3. Insert the real BLH role lineup
-- ============================================================================

-- ----- CASE MANAGEMENT (FLAGSHIP ROLES) -----

INSERT INTO role_templates (
  slug, display_name, short_description, long_description,
  responsibilities, requirements, nice_to_haves,
  pay_range_min, pay_range_max, pay_frequency,
  required_documents, optional_documents, onboarding_packet,
  active, is_public, is_evergreen, department, career_level
) VALUES
(
  'support-planner',
  'Support Planner',
  'Help adults with disabilities live the life they choose through person-centered planning.',
  'As a Support Planner at Beatrice Loving Heart, you work with participants in Maryland''s Community First Choice (CFC) program. You partner with each participant and their family to develop, implement, and monitor a Person-Centered Plan that captures what matters to them. You coordinate with service providers, advocate for participants, monitor service delivery, and document everything in LTSSMaryland. This is field-based, professional, case management work — not direct care.',
  '["Develop and update Person-Centered Plans with participants and families","Coordinate with service providers, families, and CFC program staff","Monitor service delivery and participant outcomes","Conduct monthly monitoring visits in participants'' homes and communities","Maintain documentation in LTSSMaryland","Advocate for participants'' rights, preferences, and choices","Respond to participant needs and crises during business hours"]'::jsonb,
  '["Bachelor''s degree (Social Work, Psychology, Human Services, Education, or related field strongly preferred)","Valid driver''s license, reliable transportation, and auto insurance","Pass background check and drug screen","Strong written and verbal communication skills","Ability to travel to participants throughout assigned Maryland counties","Comfort working independently and managing your own schedule"]'::jsonb,
  '["Prior case management, social work, or service coordination experience","LTSSMaryland system experience","HCBS waiver experience (CFC, DDA, ECSP, CDS)","Person-Centered Thinking (PCT) certification","Bilingual (Spanish, Amharic, French, Tagalog, or other)","Maryland county experience in PG, Montgomery, AA, Howard, or Baltimore"]'::jsonb,
  52000, 65000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","college_transcript","professional_references","auto_insurance"]'::jsonb,
  '["pct_certification","case_management_cert","additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","drug_screen_consent","confidentiality_agreement","personal_data_sheet","ltss_maryland_access_request"]'::jsonb,
  true, true, true, 'Community First Choice', 'mid'
),
(
  'senior-support-planner',
  'Senior Support Planner',
  'A seasoned Support Planner mentoring others and handling complex cases.',
  'Senior Support Planners at BLH are experienced case managers who take on the most complex CFC participants, mentor newer Support Planners, and help build best practices across the team. You still carry your own caseload but with added leadership responsibility and quality oversight.',
  '["Manage a caseload of CFC participants, including complex cases","Mentor and onboard new Support Planners","Review Person-Centered Plans for quality and compliance","Serve as a subject-matter expert on CFC policy and LTSSMaryland","Collaborate with Team Managers on team-level initiatives"]'::jsonb,
  '["Bachelor''s degree required","2+ years as a Support Planner or in CFC case management","Valid driver''s license, reliable transportation, auto insurance","Pass background check","Demonstrated documentation excellence"]'::jsonb,
  '["Master''s degree (MSW, MA in Human Services, etc.)","Bilingual","Prior mentorship or training experience"]'::jsonb,
  60000, 75000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","college_transcript","professional_references","auto_insurance"]'::jsonb,
  '["pct_certification","case_management_cert","additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","drug_screen_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Community First Choice', 'senior'
),
(
  'team-manager-sp',
  'Team Manager / Senior Support Planner',
  'Lead a team of Support Planners and shape how BLH serves the CFC population.',
  'Team Managers supervise a group of Support Planners, are accountable for the team''s quality and compliance, and represent BLH in interactions with the CFC program. You still touch some participant work but most of your time is on team leadership, coaching, and operational decisions.',
  '["Supervise a team of 6-10 Support Planners","Conduct monthly 1:1s, quarterly reviews, annual evaluations","Audit Person-Centered Plans and provide quality feedback","Triage escalations and participant complaints","Partner with HR on hiring, performance, and PIP cases","Represent BLH in CFC program meetings and audits"]'::jsonb,
  '["Bachelor''s degree required","3+ years as a Support Planner in Maryland CFC","Prior supervisory or team-lead experience","Strong understanding of CFC program rules","Pass background check"]'::jsonb,
  '["Master''s degree","Bilingual","Prior leadership in a Medicaid waiver program"]'::jsonb,
  70000, 88000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","college_transcript","professional_references","auto_insurance"]'::jsonb,
  '["pct_certification","case_management_cert","additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","drug_screen_consent","confidentiality_agreement","personal_data_sheet","supervisor_handbook_ack"]'::jsonb,
  true, true, false, 'Community First Choice', 'manager'
),
(
  'coordinator-of-community-services',
  'Coordinator of Community Services (CCS)',
  'Coordinate services for adults with intellectual and developmental disabilities under Maryland''s DDA waivers.',
  'Coordinators of Community Services work directly with DDA participants and their families to develop, implement, and monitor Individual Support Plans. CCS is the linchpin between participant goals and the services that make those goals real — provider coordination, monthly monitoring visits, advocacy, and crisis response. This role requires per COMAR 10.22 a bachelor''s degree plus one year of experience with people who have intellectual or developmental disabilities.',
  '["Develop and update Individual Support Plans (ISPs) for DDA participants","Coordinate with providers, families, and the Developmental Disabilities Administration","Conduct monthly monitoring visits in participants'' homes and communities","Maintain documentation in LTSSMaryland","Advocate for participants in service planning and crisis situations","Coordinate cross-disciplinary care (behavioral, medical, vocational, day services)"]'::jsonb,
  '["Bachelor''s degree in human services or related field (REQUIRED per COMAR 10.22)","Minimum 1 year experience working with people with intellectual or developmental disabilities","Valid driver''s license, reliable transportation, auto insurance","Strong writing and documentation skills","Pass background check and drug screen"]'::jsonb,
  '["Master''s degree (MSW, MA Special Education, MA Counseling, etc.)","Prior CCS or case management experience in Maryland","LTSSMaryland proficiency","Person-Centered Thinking certification","Bilingual"]'::jsonb,
  55000, 70000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","college_transcript","professional_references","auto_insurance"]'::jsonb,
  '["pct_certification","case_management_cert","additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","drug_screen_consent","confidentiality_agreement","personal_data_sheet","ltss_maryland_access_request","dda_orientation_ack"]'::jsonb,
  true, true, true, 'Department of Developmental Disability', 'mid'
),
(
  'lead-ccs',
  'Lead Coordinator of Community Services',
  'A senior CCS leading complex cases and supporting team quality.',
  'Lead CCSs handle the most complex DDA participants and serve as a resource for the broader CCS team. You contribute to policy interpretation, mentor newer CCSs, and represent BLH in higher-stakes meetings with DDA and providers.',
  '["Carry a caseload of complex DDA participants","Mentor and onboard new CCSs","Review ISPs for quality and DDA compliance","Serve as policy and process expert for the CCS team","Coordinate with Team Managers on operational improvements"]'::jsonb,
  '["Bachelor''s degree required","3+ years as a CCS in Maryland DDA","Strong knowledge of DDA waivers and LTSSMaryland","Pass background check"]'::jsonb,
  '["Master''s degree","Prior mentorship or supervisory experience","Bilingual"]'::jsonb,
  62000, 78000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","college_transcript","professional_references","auto_insurance"]'::jsonb,
  '["pct_certification","case_management_cert","additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","drug_screen_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Department of Developmental Disability', 'senior'
),
(
  'team-manager-ccs',
  'Team Manager / Senior Coordinator of Community Services',
  'Lead the CCS team and represent BLH in DDA partnerships.',
  'Team Managers supervise CCSs, drive team quality and compliance, and lead BLH''s relationship with the DDA. You may carry a small caseload but the bulk of your work is people leadership, quality oversight, and operational decisions.',
  '["Supervise a team of 6-10 CCSs","Conduct monthly 1:1s, quarterly reviews, annual evaluations","Audit ISPs and provide quality feedback","Triage escalations and complaints","Partner with HR on hiring, performance, and PIPs","Represent BLH in DDA meetings, audits, and contract reviews"]'::jsonb,
  '["Bachelor''s degree required","4+ years as a CCS in Maryland DDA","Prior supervisory or team-lead experience","Strong understanding of DDA waivers and COMAR regulations","Pass background check"]'::jsonb,
  '["Master''s degree","Bilingual","Prior leadership in a Medicaid waiver program"]'::jsonb,
  72000, 90000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","college_transcript","professional_references","auto_insurance"]'::jsonb,
  '["pct_certification","case_management_cert","additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","drug_screen_consent","confidentiality_agreement","personal_data_sheet","supervisor_handbook_ack"]'::jsonb,
  true, true, false, 'Department of Developmental Disability', 'manager'
),

-- ----- ADMINISTRATION / SUPPORT -----

(
  'administrative-assistant',
  'Administrative Assistant',
  'Keep BLH running with strong organization, follow-through, and care.',
  'Administrative Assistants at BLH support every function of the agency — coordinating schedules, preparing documents, supporting the case management teams with paperwork, and being the friendly first point of contact for many of our participants and providers.',
  '["Manage calendars, schedules, and team coordination","Prepare documents, reports, and correspondence","Support the case management teams with administrative paperwork","Maintain organized records, both physical and digital","Answer phones, route inquiries, and follow up on requests","Other administrative duties as needed"]'::jsonb,
  '["High school diploma or GED (associate''s or bachelor''s preferred)","Strong written and verbal communication","Proficiency with Microsoft Office and Google Workspace","Reliable, organized, detail-oriented","Pass background check"]'::jsonb,
  '["Prior administrative experience in healthcare, nonprofit, or human services","Bilingual","Experience with Medicaid programs or HCBS waivers"]'::jsonb,
  18.00, 25.00, 'hourly',
  '["drivers_license","ssn_card","diploma_or_ged","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Administrative Assistance', 'entry'
),
(
  'office-manager',
  'Office Manager',
  'Run BLH''s daily office operations and keep the team supported.',
  'The Office Manager makes sure BLH''s administrative engine runs smoothly. You manage office logistics, vendor relationships, supplies, facilities, and oversee a small administrative team. You partner with HR and Finance on operational matters.',
  '["Manage office operations, supplies, and vendor relationships","Supervise administrative staff (typically 2-4 reports)","Coordinate facilities, IT support requests, and equipment","Support HR with onboarding logistics","Manage office budgets and expense reconciliation"]'::jsonb,
  '["Bachelor''s degree preferred (associate''s plus experience considered)","3+ years of office management or operations experience","Strong organizational and leadership skills","Pass background check"]'::jsonb,
  '["Experience in healthcare, nonprofit, or government","Bilingual","Bookkeeping or financial-ops experience"]'::jsonb,
  50000, 70000, 'salary',
  '["drivers_license","ssn_card","diploma_or_ged","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet","supervisor_handbook_ack"]'::jsonb,
  true, true, false, 'Supervisors/Managers', 'manager'
),
(
  'assistant-program-supervisor',
  'Assistant Program Supervisor',
  'Support program leadership and help operations run smoothly.',
  'Assistant Program Supervisors partner with senior program leaders on day-to-day operations across BLH''s case management teams. You take on project work, support team management, and grow toward future supervisory roles.',
  '["Support senior supervisors on program operations","Coordinate cross-team projects and process improvements","Help track team performance metrics and quality measures","Step in to support direct team management as needed"]'::jsonb,
  '["Bachelor''s degree required","2+ years of case management, coordination, or program experience","Strong organization and writing skills","Pass background check"]'::jsonb,
  '["Master''s degree","Prior team-lead experience","Bilingual"]'::jsonb,
  55000, 70000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Supervisors/Managers', 'mid'
),
(
  'supervisor',
  'Supervisor',
  'Lead a team and own outcomes across BLH operations.',
  'Supervisor roles at BLH vary by department, but the work is consistent: lead a team, develop your people, own outcomes. Depending on where you land, you might supervise Support Planners, CCSs, administrative staff, or onboarding specialists.',
  '["Supervise a team of 4-10 staff","Conduct regular 1:1s, performance reviews, and goal-setting","Maintain team quality, compliance, and culture","Partner with HR on hiring, performance, and people decisions"]'::jsonb,
  '["Bachelor''s degree preferred","3+ years of supervisory experience","Strong communication and leadership skills","Pass background check"]'::jsonb,
  '["Master''s degree","Prior supervisory experience in case management or Medicaid waivers","Bilingual"]'::jsonb,
  60000, 80000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet","supervisor_handbook_ack"]'::jsonb,
  true, true, false, 'Supervisors/Managers', 'manager'
),

-- ----- HR / RECRUITING / ONBOARDING -----

(
  'talent-acquisition-manager',
  'Talent Acquisition Manager',
  'Build the team that helps Maryland families and DDA participants.',
  'BLH is growing. The Talent Acquisition Manager leads our recruiting function — sourcing top Support Planners and CCSs, building pipelines for hard-to-fill roles, and partnering with hiring managers to make great hires. You''ll have full ownership of our recruiting stack and the candidate experience.',
  '["Lead end-to-end recruiting for SP, CCS, and supervisory roles","Build sourcing strategies for hard-to-fill positions","Manage the recruiting team and our ATS","Partner with hiring managers on calibration, interviews, and offers","Drive recruiting metrics and continuous improvement"]'::jsonb,
  '["Bachelor''s degree preferred","3+ years of full-cycle recruiting","Prior healthcare, nonprofit, or human services recruiting a plus","Strong organization and communication","Pass background check"]'::jsonb,
  '["Master''s degree","Prior leadership of a recruiting team","Experience recruiting case managers or HCBS waiver staff","Maryland-specific recruiting expertise"]'::jsonb,
  65000, 85000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet","supervisor_handbook_ack"]'::jsonb,
  true, true, false, 'Human Resources', 'manager'
),
(
  'employee-relations-specialist',
  'Employee Relations Specialist',
  'Be the trusted resource for BLH''s 100+ employees.',
  'Employee Relations Specialists at BLH are the human face of HR — coaching managers, supporting employees through difficult moments, investigating concerns fairly, and helping us live up to our culture every day.',
  '["Coach managers on performance conversations and people decisions","Support employees through workplace concerns and conflict","Conduct fair, thorough investigations of complaints","Maintain compliance with employment law and BLH policy","Partner with leadership on policy development"]'::jsonb,
  '["Bachelor''s degree required (HR, Business, or related)","3+ years of HR generalist or ER-specific experience","Strong knowledge of federal and Maryland employment law","Discretion, empathy, and excellent judgment","Pass background check"]'::jsonb,
  '["SHRM-CP, SHRM-SCP, PHR, or SPHR certification","Master''s in HR or related field","Prior healthcare or nonprofit experience"]'::jsonb,
  60000, 78000, 'salary',
  '["drivers_license","ssn_card","bachelors_diploma","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Human Resources', 'mid'
),
(
  'onboarding-specialist',
  'Onboarding Specialist',
  'Give every new hire a smooth, supported start at BLH.',
  'The Onboarding Specialist owns the new-hire journey from offer accepted through fully active employee. You make sure paperwork is complete, expectations are clear, and every new BLH staffer feels welcomed and prepared on day one.',
  '["Manage new hire onboarding from offer to day-30","Coordinate paperwork, background checks, and compliance","Run new hire orientation sessions","Track onboarding completion and follow up on missing items","Maintain employee files in BLH''s systems"]'::jsonb,
  '["High school diploma or GED (bachelor''s preferred)","2+ years in HR coordination, onboarding, or administrative work","Strong organization, detail orientation, and follow-through","Comfort with HR systems and digital documents","Pass background check"]'::jsonb,
  '["Prior onboarding-specific experience","SHRM-CP or PHR","Bilingual","Experience with healthcare or DDA programs"]'::jsonb,
  20.00, 28.00, 'hourly',
  '["drivers_license","ssn_card","diploma_or_ged","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Onboarding', 'entry'
),

-- ----- SPECIALIZED -----

(
  'interpreter',
  'Interpreter',
  'Help BLH connect with participants and families across languages.',
  'Many of the participants BLH serves are most comfortable communicating in a language other than English. Interpreters at BLH support Support Planners and CCSs during home visits, planning meetings, and family conversations — helping make sure every participant''s voice is fully heard.',
  '["Provide consecutive interpretation between English and your target language(s)","Support Support Planners and CCSs during home visits and planning meetings","Translate written documents as needed","Maintain confidentiality and professional standards","Travel to participants throughout assigned counties"]'::jsonb,
  '["Fluent in English and one or more of: Spanish, Amharic, French, Tagalog, or other","Valid driver''s license, reliable transportation","Strong cultural competence","Pass background check","High school diploma minimum"]'::jsonb,
  '["Medical or community interpreter certification","Bachelor''s degree","Prior interpretation experience in healthcare or social services"]'::jsonb,
  22.00, 32.00, 'hourly',
  '["drivers_license","ssn_card","diploma_or_ged","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Administrative Assistance', 'mid'
),
(
  'help-desk-specialist',
  'In-Office Help Desk Specialist',
  'Keep BLH''s team productive and our technology working.',
  'The Help Desk Specialist is the friendly first responder for any technology question at BLH — fixing what''s broken, setting up new hires with the right tools, and helping our staff focus on their participants instead of fighting their computers.',
  '["Provide first-line technical support across the office","Set up new hire accounts, equipment, and software","Maintain inventory of devices, accessories, and licenses","Troubleshoot common SaaS and hardware issues","Escalate to managed IT services when needed"]'::jsonb,
  '["High school diploma or GED (associate''s or bachelor''s preferred)","Prior IT support or help desk experience","Comfort with Windows, macOS, Google Workspace, Office 365","Strong customer service orientation","Pass background check"]'::jsonb,
  '["A+ certification or equivalent","Bachelor''s in IT, CS, or related","Prior healthcare or nonprofit IT experience"]'::jsonb,
  22.00, 32.00, 'hourly',
  '["drivers_license","ssn_card","diploma_or_ged","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Administrative Assistance', 'entry'
),
(
  'data-entry-administrator',
  'Data Entry Administrator',
  'Keep BLH''s records accurate and current.',
  'Data Entry Administrators are the quiet backbone of BLH''s operations — making sure every record is accurate, complete, and up to date across our systems. Precision matters here. So does discretion.',
  '["Enter and maintain records across BLH''s systems (HRIS, ATS, LTSSMaryland support)","Audit data for completeness and accuracy","Generate routine reports for leadership","Maintain strict confidentiality of participant and employee data"]'::jsonb,
  '["High school diploma or GED","Strong typing speed and accuracy","Detail-oriented and patient","Discretion with sensitive information","Pass background check"]'::jsonb,
  '["Prior data entry experience in healthcare or human services","Excel proficiency","Bilingual"]'::jsonb,
  18.00, 24.00, 'hourly',
  '["drivers_license","ssn_card","diploma_or_ged","professional_references"]'::jsonb,
  '["additional_certifications"]'::jsonb,
  '["w4","mw507","i9","direct_deposit","emergency_contact","handbook_ack","background_consent","confidentiality_agreement","personal_data_sheet"]'::jsonb,
  true, true, false, 'Administrative Assistance', 'entry'
)
ON CONFLICT (slug) DO UPDATE SET
  display_name = EXCLUDED.display_name,
  short_description = EXCLUDED.short_description,
  long_description = EXCLUDED.long_description,
  responsibilities = EXCLUDED.responsibilities,
  requirements = EXCLUDED.requirements,
  nice_to_haves = EXCLUDED.nice_to_haves,
  pay_range_min = EXCLUDED.pay_range_min,
  pay_range_max = EXCLUDED.pay_range_max,
  pay_frequency = EXCLUDED.pay_frequency,
  required_documents = EXCLUDED.required_documents,
  optional_documents = EXCLUDED.optional_documents,
  onboarding_packet = EXCLUDED.onboarding_packet,
  is_evergreen = EXCLUDED.is_evergreen,
  department = EXCLUDED.department,
  career_level = EXCLUDED.career_level,
  updated_at = now();

-- ============================================================================
-- 4. Quick sanity-check view
-- ============================================================================
COMMENT ON TABLE role_templates IS 'Role definitions for BLH. Source of truth for the public /apply/[role] page and role-specific config (required documents, AI signal weights, onboarding packets). BLH is a case management agency — does NOT provide direct care.';
