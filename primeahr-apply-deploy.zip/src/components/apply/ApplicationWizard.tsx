"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ResumeUploadStep } from "./steps/ResumeUploadStep";
import { PersonalInfoStep } from "./steps/PersonalInfoStep";
import { ExperienceStep } from "./steps/ExperienceStep";
import { DocumentsStep } from "./steps/DocumentsStep";
import { BackgroundStep } from "./steps/BackgroundStep";
import { SignSubmitStep } from "./steps/SignSubmitStep";
import { ConfirmationStep } from "./steps/ConfirmationStep";
import type { ApplicationData, ParsedResume } from "@/lib/apply/application-schema";

export type WizardStep =
  | "resume"
  | "personal"
  | "experience"
  | "documents"
  | "background"
  | "sign"
  | "done";

const STEPS: Array<{
  key: WizardStep;
  num: number;
  name: string;
  hint: string;
}> = [
  { key: "resume", num: 1, name: "Resume", hint: "Upload or skip" },
  { key: "personal", num: 2, name: "About you", hint: "Contact & info" },
  { key: "experience", num: 3, name: "Experience", hint: "Work, school, certs" },
  { key: "documents", num: 4, name: "Documents", hint: "ID, license, certs" },
  { key: "background", num: 5, name: "Eligibility", hint: "Quick checks" },
  { key: "sign", num: 6, name: "Sign & submit", hint: "Final step" },
];

interface RoleData {
  slug: string;
  displayName: string;
  longDescription: string | null;
  responsibilities: string[];
  requirements: string[];
  niceToHaves: string[];
  requiredDocuments: string[];
  optionalDocuments: string[];
}

interface ResumedApplication {
  applicationId: string;
  resumeToken: string;
  currentStep: number;
  formData: unknown;
}

interface Props {
  role: RoleData;
  requisitionId: string | null;
  referralSource: string | null;
  resumedApplication: ResumedApplication | null;
}

export function ApplicationWizard({
  role,
  requisitionId,
  referralSource,
  resumedApplication,
}: Props) {
  const [step, setStep] = useState<WizardStep>(() => {
    if (resumedApplication) {
      return stepFromNumber(resumedApplication.currentStep);
    }
    return "resume";
  });

  const [applicationId, setApplicationId] = useState<string | null>(
    resumedApplication?.applicationId ?? null
  );
  const [resumeToken, setResumeToken] = useState<string | null>(
    resumedApplication?.resumeToken ?? null
  );

  const [formData, setFormData] = useState<ApplicationData>(() => {
    return (resumedApplication?.formData as ApplicationData) ?? {};
  });

  const [parsedResume, setParsedResume] = useState<ParsedResume | null>(null);
  const [aiSummary, setAiSummary] = useState<string>("");

  const [saving, setSaving] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);

  // ===== Auto-save with debounce =====
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scheduleSave = useCallback(
    (data: ApplicationData, currentStepNumber: number) => {
      if (!applicationId || !resumeToken) return;

      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(async () => {
        setSaving(true);
        try {
          const res = await fetch("/api/apply/save", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              applicationId,
              resumeToken,
              currentStep: currentStepNumber,
              formData: data,
            }),
          });
          if (res.ok) setLastSavedAt(new Date());
        } catch (e) {
          console.error("[wizard] save failed:", e);
        } finally {
          setSaving(false);
        }
      }, 1200);
    },
    [applicationId, resumeToken]
  );

  // Initialize the application if we don't have one yet (lazy — when needed)
  const ensureApplication = useCallback(async (): Promise<{
    applicationId: string;
    resumeToken: string;
  }> => {
    if (applicationId && resumeToken) {
      return { applicationId, resumeToken };
    }

    const res = await fetch("/api/apply/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        roleSlug: role.slug,
        requisitionId,
        referralSource,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: "unknown" }));
      throw new Error(err.error ?? "Failed to start application");
    }

    const data = await res.json();
    setApplicationId(data.applicationId);
    setResumeToken(data.resumeToken);
    return { applicationId: data.applicationId, resumeToken: data.resumeToken };
  }, [applicationId, resumeToken, role.slug, requisitionId, referralSource]);

  // ===== Step navigation =====
  const currentStepNum = useMemo(() => stepNumber(step), [step]);

  const updateFormData = useCallback(
    (patch: Partial<ApplicationData>) => {
      setFormData((prev) => {
        const next = { ...prev, ...patch };
        scheduleSave(next, currentStepNum);
        return next;
      });
    },
    [scheduleSave, currentStepNum]
  );

  const goToStep = useCallback(
    (next: WizardStep) => {
      setStep(next);
      const nextNum = stepNumber(next);
      // Persist the step change immediately
      if (applicationId && resumeToken) {
        scheduleSave(formData, nextNum);
      }
      // Scroll to top of wizard
      if (typeof window !== "undefined") {
        document.querySelector(".wizard-frame")?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    },
    [applicationId, resumeToken, formData, scheduleSave]
  );

  const goNext = useCallback(() => {
    const idx = STEPS.findIndex((s) => s.key === step);
    if (idx < STEPS.length - 1) {
      goToStep(STEPS[idx + 1].key);
    } else if (step === "sign") {
      // sign is the last form step before 'done'; submission handled by SignSubmitStep
    }
  }, [step, goToStep]);

  const goPrev = useCallback(() => {
    const idx = STEPS.findIndex((s) => s.key === step);
    if (idx > 0) goToStep(STEPS[idx - 1].key);
  }, [step, goToStep]);

  // ===== Render =====
  if (step === "done") {
    return <ConfirmationStep role={role} aiSummary={aiSummary} />;
  }

  return (
    <div className="wizard-shell">
      <div className="wizard-frame">
        <aside className="wizard-rail">
          <h2 className="wizard-rail-title">Your application</h2>
          {STEPS.map((s) => {
            const isActive = s.key === step;
            const isComplete = stepNumber(s.key) < currentStepNum;
            return (
              <button
                key={s.key}
                type="button"
                className="rail-step"
                data-active={isActive}
                data-complete={isComplete}
                onClick={() => {
                  // Allow back-nav to any completed step
                  if (isComplete || isActive) goToStep(s.key);
                }}
                aria-current={isActive ? "step" : undefined}
              >
                <span className="rail-step-num">
                  {isComplete ? <CheckIcon /> : s.num}
                </span>
                <span className="rail-step-label">
                  <span className="rail-step-name">{s.name}</span>
                  <span className="rail-step-hint">{s.hint}</span>
                </span>
              </button>
            );
          })}
        </aside>

        <section className="wizard-stage" key={step}>
          <div className="step-enter">
            {step === "resume" && (
              <ResumeUploadStep
                role={role}
                onContinue={async ({ parsedResume: pr, summary }) => {
                  if (pr) setParsedResume(pr);
                  if (summary) setAiSummary(summary);
                  goToStep("personal");
                }}
                ensureApplication={ensureApplication}
                onUpdateFormData={updateFormData}
                currentFormData={formData}
              />
            )}

            {step === "personal" && (
              <PersonalInfoStep
                formData={formData}
                onChange={updateFormData}
                onNext={goNext}
                onPrev={goPrev}
                hasParsedResume={!!parsedResume}
                aiSummary={aiSummary}
              />
            )}

            {step === "experience" && (
              <ExperienceStep
                formData={formData}
                onChange={updateFormData}
                onNext={goNext}
                onPrev={goPrev}
                hasParsedResume={!!parsedResume}
              />
            )}

            {step === "documents" && (
              <DocumentsStep
                role={role}
                applicationId={applicationId}
                resumeToken={resumeToken}
                ensureApplication={ensureApplication}
                formData={formData}
                onChange={updateFormData}
                onNext={goNext}
                onPrev={goPrev}
              />
            )}

            {step === "background" && (
              <BackgroundStep
                formData={formData}
                onChange={updateFormData}
                onNext={goNext}
                onPrev={goPrev}
              />
            )}

            {step === "sign" && (
              <SignSubmitStep
                applicationId={applicationId}
                resumeToken={resumeToken}
                formData={formData}
                onChange={updateFormData}
                onPrev={goPrev}
                onSubmitted={() => setStep("done")}
                role={role}
              />
            )}
          </div>

          <SaveStatus saving={saving} lastSavedAt={lastSavedAt} />
        </section>
      </div>
    </div>
  );
}

function SaveStatus({
  saving,
  lastSavedAt,
}: {
  saving: boolean;
  lastSavedAt: Date | null;
}) {
  if (saving) {
    return (
      <div className="btn-saving" style={{ marginTop: 12 }}>
        <span className="btn-saving-dot" />
        Saving…
      </div>
    );
  }
  if (lastSavedAt) {
    return (
      <div className="btn-saving" style={{ marginTop: 12 }}>
        <CheckIcon size={10} />
        Saved · {timeAgo(lastSavedAt)}
      </div>
    );
  }
  return null;
}

function CheckIcon({ size = 12 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 12 12" fill="none" aria-hidden>
      <path
        d="M2.5 6.5l2.5 2.5 4.5-5"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function timeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 5) return "just now";
  if (seconds < 60) return `${seconds}s ago`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m}m ago`;
  return date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

function stepNumber(s: WizardStep): number {
  const found = STEPS.find((x) => x.key === s);
  return found?.num ?? 1;
}

function stepFromNumber(n: number): WizardStep {
  const found = STEPS.find((s) => s.num === n);
  return found?.key ?? "resume";
}
