"use client";

import { useState } from "react";
import type { ApplicationData } from "@/lib/apply/application-schema";
import { Field, SectionDivider, YesNoField } from "./PersonalInfoStep";

interface Props {
  formData: ApplicationData;
  onChange: (patch: Partial<ApplicationData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function BackgroundStep({ formData, onChange, onNext, onPrev }: Props) {
  const bg = formData.background ?? {};
  const eeo = bg.voluntaryEEO ?? {};

  const update = (patch: Partial<NonNullable<ApplicationData["background"]>>) => {
    onChange({ background: { ...bg, ...patch } as ApplicationData["background"] });
  };

  const updateEEO = (patch: Partial<typeof eeo>) => {
    update({ voluntaryEEO: { ...eeo, ...patch } });
  };

  const [showEEO, setShowEEO] = useState(false);

  return (
    <>
      <div className="stage-header">
        <div className="stage-eyebrow">Step 5 of 6 · Eligibility</div>
        <h2 className="stage-title">A few quick yes/no questions.</h2>
        <p className="stage-sub">
          Required for state and federal compliance. Honest answers — you won't be auto-rejected
          for any single answer, but we do need them for our records.
        </p>
      </div>

      <SectionDivider label="Driving" />
      <div style={{ display: "flex", flexDirection: "column", gap: 18, marginTop: 16 }}>
        <YesNoField
          label="Do you have a valid driver's license?"
          required
          value={bg.hasValidDriversLicense}
          onChange={(v) => update({ hasValidDriversLicense: v })}
        />

        {bg.hasValidDriversLicense && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <Field
              label="State of issue"
              name="dlState"
              value={bg.driversLicenseState ?? ""}
              onChange={(v) => update({ driversLicenseState: v })}
              placeholder="MD"
            />
            <Field
              label="Expiration date"
              type="date"
              name="dlExpires"
              value={bg.driversLicenseExpires ?? ""}
              onChange={(v) => update({ driversLicenseExpires: v })}
            />
          </div>
        )}

        <YesNoField
          label="Do you have reliable transportation to and from work?"
          required
          value={bg.hasReliableTransportation}
          onChange={(v) => update({ hasReliableTransportation: v })}
        />
        <YesNoField
          label="Do you have current auto insurance?"
          required
          value={bg.hasAutoInsurance}
          onChange={(v) => update({ hasAutoInsurance: v })}
        />
      </div>

      <SectionDivider label="Eligibility" />
      <div style={{ display: "flex", flexDirection: "column", gap: 18, marginTop: 16 }}>
        <YesNoField
          label="Are you legally authorized to work in the United States?"
          required
          value={bg.authorizedToWorkInUS}
          onChange={(v) => update({ authorizedToWorkInUS: v })}
        />
        <YesNoField
          label="Are you 18 years of age or older?"
          required
          value={bg.age18OrOlder}
          onChange={(v) => update({ age18OrOlder: v })}
        />
      </div>

      <SectionDivider label="Counties you can serve" />
      <div style={{ marginTop: 16, marginBottom: 4 }}>
        <p style={{ fontSize: 13.5, color: "var(--apply-ink-muted)", margin: "0 0 12px", lineHeight: 1.55 }}>
          Most of our roles involve field visits to participants' homes and communities. Select all Maryland
          jurisdictions where you can reliably travel for monthly visits. Optional but very helpful for matching.
        </p>
        <CountiesPicker
          selected={bg.countiesServable ?? []}
          onChange={(v) => update({ countiesServable: v })}
        />
      </div>

      <SectionDivider label="Pre-employment checks" />
      <div style={{ display: "flex", flexDirection: "column", gap: 18, marginTop: 16 }}>
        <YesNoField
          label="Are you willing to consent to a background check?"
          required
          value={bg.willingToCompleteBackgroundCheck}
          onChange={(v) => update({ willingToCompleteBackgroundCheck: v })}
        />
        <YesNoField
          label="Are you willing to complete a drug screen prior to your start date?"
          required
          value={bg.willingToCompleteDrugScreen}
          onChange={(v) => update({ willingToCompleteDrugScreen: v })}
        />
      </div>

      <SectionDivider label="Disclosure" />
      <div style={{ display: "flex", flexDirection: "column", gap: 18, marginTop: 16 }}>
        <div
          style={{
            background: "var(--apply-cream-deeper)",
            border: "1px solid var(--apply-border)",
            borderRadius: "var(--apply-r)",
            padding: "14px 16px",
            fontSize: 13,
            color: "var(--apply-ink-muted)",
            lineHeight: 1.5,
          }}
        >
          A conviction does <em>not</em> automatically disqualify you from employment. We
          consider the nature, time elapsed, and relevance to the role you're applying for.
        </div>

        <YesNoField
          label="Have you ever been convicted of a crime?"
          required
          value={bg.hasBeenConvictedOfCrime}
          onChange={(v) => update({ hasBeenConvictedOfCrime: v })}
        />

        {bg.hasBeenConvictedOfCrime && (
          <Field
            label="Please briefly describe the circumstances"
            name="convictionExplanation"
            value={bg.convictionExplanation ?? ""}
            onChange={(v) => update({ convictionExplanation: v })}
            hint="Date, nature, and any rehabilitation."
          />
        )}
      </div>

      {/* Voluntary EEO */}
      <SectionDivider label="Voluntary — EEO disclosures" />
      <div
        style={{
          background: "var(--apply-paper-soft)",
          border: "1px solid var(--apply-border)",
          borderRadius: "var(--apply-r-lg)",
          padding: "20px 24px",
          marginTop: 16,
        }}
      >
        <p style={{ fontSize: 13.5, color: "var(--apply-ink-muted)", margin: "0 0 12px", lineHeight: 1.6 }}>
          Federal law requires us to ask these questions but answering is entirely{" "}
          <strong>optional</strong>. We collect this data in aggregate only — it never
          affects hiring decisions.
        </p>

        {!showEEO && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => setShowEEO(true)}
            style={{ marginTop: 4 }}
          >
            Show the questions
          </button>
        )}

        {showEEO && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 12 }}>
            <SimpleSelect
              label="Gender"
              value={eeo.gender ?? ""}
              onChange={(v) => updateEEO({ gender: v })}
              options={[
                { value: "female", label: "Female" },
                { value: "male", label: "Male" },
                { value: "nonbinary", label: "Non-binary" },
                { value: "other", label: "Other" },
                { value: "decline", label: "Decline to answer" },
              ]}
            />

            <SimpleSelect
              label="Ethnicity"
              value={eeo.ethnicity ?? ""}
              onChange={(v) => updateEEO({ ethnicity: v })}
              options={[
                { value: "asian", label: "Asian" },
                { value: "black", label: "Black or African American" },
                { value: "hispanic", label: "Hispanic or Latino" },
                { value: "native_american", label: "American Indian or Alaska Native" },
                { value: "pacific_islander", label: "Native Hawaiian or Pacific Islander" },
                { value: "white", label: "White" },
                { value: "two_or_more", label: "Two or more races" },
                { value: "other", label: "Other" },
                { value: "decline", label: "Decline to answer" },
              ]}
            />

            <SimpleSelect
              label="Veteran status"
              value={eeo.veteranStatus ?? ""}
              onChange={(v) => updateEEO({ veteranStatus: v })}
              options={[
                { value: "veteran", label: "I am a veteran" },
                { value: "protected_veteran", label: "I am a protected veteran" },
                { value: "not_veteran", label: "I am not a veteran" },
                { value: "decline", label: "Decline to answer" },
              ]}
            />

            <SimpleSelect
              label="Disability status"
              value={eeo.disabilityStatus ?? ""}
              onChange={(v) => updateEEO({ disabilityStatus: v })}
              options={[
                { value: "yes", label: "Yes, I have a disability" },
                { value: "no", label: "No, I do not have a disability" },
                { value: "decline", label: "Decline to answer" },
              ]}
            />
          </div>
        )}
      </div>

      <div className="wizard-nav">
        <button type="button" className="btn btn-ghost" onClick={onPrev}>
          ← Back
        </button>
        <button type="button" className="btn btn-primary" onClick={onNext}>
          Continue → sign & submit
          <ArrowRight />
        </button>
      </div>
    </>
  );
}

function SimpleSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: Array<{ value: string; label: string }>;
}) {
  return (
    <div className="field">
      <label className="field-label">{label}</label>
      <select className="field-select" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Select an option</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// All 23 Maryland counties + Baltimore City, in roughly the order BLH staff most often serve.
const MARYLAND_COUNTIES = [
  "Prince George's",
  "Montgomery",
  "Anne Arundel",
  "Howard",
  "Baltimore City",
  "Baltimore County",
  "Charles",
  "Calvert",
  "St. Mary's",
  "Frederick",
  "Carroll",
  "Harford",
  "Cecil",
  "Queen Anne's",
  "Talbot",
  "Caroline",
  "Kent",
  "Dorchester",
  "Wicomico",
  "Somerset",
  "Worcester",
  "Washington",
  "Allegany",
  "Garrett",
];

function CountiesPicker({
  selected,
  onChange,
}: {
  selected: string[];
  onChange: (next: string[]) => void;
}) {
  const toggle = (county: string) => {
    if (selected.includes(county)) {
      onChange(selected.filter((c) => c !== county));
    } else {
      onChange([...selected, county]);
    }
  };

  const selectAll = () => onChange([...MARYLAND_COUNTIES]);
  const clear = () => onChange([]);

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button
          type="button"
          onClick={selectAll}
          style={{
            fontFamily: "inherit",
            fontSize: 12,
            fontWeight: 600,
            padding: "5px 12px",
            borderRadius: 100,
            border: "1px solid var(--apply-border)",
            background: "var(--apply-paper-soft)",
            color: "var(--apply-ink-muted)",
            cursor: "pointer",
          }}
        >
          Select all
        </button>
        {selected.length > 0 && (
          <button
            type="button"
            onClick={clear}
            style={{
              fontFamily: "inherit",
              fontSize: 12,
              fontWeight: 600,
              padding: "5px 12px",
              borderRadius: 100,
              border: "1px solid var(--apply-border)",
              background: "var(--apply-paper-soft)",
              color: "var(--apply-ink-muted)",
              cursor: "pointer",
            }}
          >
            Clear ({selected.length})
          </button>
        )}
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {MARYLAND_COUNTIES.map((c) => {
          const active = selected.includes(c);
          return (
            <button
              key={c}
              type="button"
              onClick={() => toggle(c)}
              style={{
                fontFamily: "inherit",
                fontSize: 13,
                fontWeight: 500,
                padding: "7px 14px",
                borderRadius: 100,
                border: `1px solid ${active ? "var(--apply-emerald)" : "var(--apply-border)"}`,
                background: active ? "var(--apply-emerald-tint)" : "var(--apply-paper-soft)",
                color: active ? "var(--apply-emerald-deep)" : "var(--apply-ink-2)",
                cursor: "pointer",
                transition: "all 0.18s var(--apply-ease)",
              }}
            >
              {c}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ArrowRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path d="M3 7h8m-3-3l3 3-3 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
