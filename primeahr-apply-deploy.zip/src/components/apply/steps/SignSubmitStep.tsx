"use client";

import { useRef, useState, useEffect, useCallback } from "react";
import type { ApplicationData } from "@/lib/apply/application-schema";
import { Field } from "./PersonalInfoStep";

interface Props {
  applicationId: string | null;
  resumeToken: string | null;
  formData: ApplicationData;
  onChange: (patch: Partial<ApplicationData>) => void;
  onPrev: () => void;
  onSubmitted: () => void;
  role: { displayName: string };
}

export function SignSubmitStep({
  applicationId,
  resumeToken,
  formData,
  onChange,
  onPrev,
  onSubmitted,
  role,
}: Props) {
  const signature = formData.signature ?? {};

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const update = (patch: Partial<NonNullable<ApplicationData["signature"]>>) => {
    onChange({ signature: { ...signature, ...patch } });
  };

  // Pre-fill full legal name from personal info
  useEffect(() => {
    if (!signature.fullLegalName && formData.personal?.firstName) {
      const name = [
        formData.personal.firstName,
        formData.personal.middleName,
        formData.personal.lastName,
      ]
        .filter(Boolean)
        .join(" ");
      update({ fullLegalName: name });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const canSubmit =
    !!signature.certifyTruthful &&
    !!signature.authorizeBackgroundCheck &&
    !!signature.acceptTermsAndPrivacy &&
    !!signature.signatureData &&
    !!signature.fullLegalName?.trim() &&
    !submitting;

  const handleSubmit = async () => {
    if (!applicationId || !resumeToken) {
      setSubmitError("Application not initialized. Please refresh and try again.");
      return;
    }
    setSubmitError(null);
    setSubmitting(true);

    try {
      const res = await fetch("/api/apply/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId,
          resumeToken,
          formData,
          signature,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setSubmitError(data.error ?? "Submission failed. Please check your form and try again.");
        return;
      }

      onSubmitted();
    } catch (e) {
      setSubmitError(e instanceof Error ? e.message : "Submission failed.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <div className="stage-header">
        <div className="stage-eyebrow">Step 6 of 6 · Sign & submit</div>
        <h2 className="stage-title">One last thing — sign your application.</h2>
        <p className="stage-sub">
          Review the certifications below, sign with your finger or mouse, and submit. We'll
          email you a confirmation right away.
        </p>
      </div>

      <ApplicationReview formData={formData} roleName={role.displayName} />

      <div style={{ marginTop: 28 }}>
        <AgreementBlock
          checked={!!signature.certifyTruthful}
          onChange={(v) => update({ certifyTruthful: v })}
          title="Truthfulness certification"
          body="I certify that the information I've provided in this application is true and complete to the best of my knowledge. I understand that false statements may result in withdrawal of an offer or termination of employment."
        />
        <AgreementBlock
          checked={!!signature.authorizeBackgroundCheck}
          onChange={(v) => update({ authorizeBackgroundCheck: v })}
          title="Background check authorization"
          body="I authorize Beatrice Loving Heart and its agents to conduct a criminal background check, verify references and employment, and check applicable Medicaid program exclusion databases (OIG, SAM.gov). I understand BLH provides case management and coordination services to Medicaid waiver participants, and that a background check is a standard requirement for this work."
        />
        <AgreementBlock
          checked={!!signature.acceptTermsAndPrivacy}
          onChange={(v) => update({ acceptTermsAndPrivacy: v })}
          title="Terms & Privacy"
          body={
            <>
              I have read and agree to the{" "}
              <a href="/terms" target="_blank" rel="noreferrer" style={inlineLink}>
                terms of service
              </a>{" "}
              and{" "}
              <a href="/privacy" target="_blank" rel="noreferrer" style={inlineLink}>
                privacy policy
              </a>
              . I understand my information will be stored securely and used only for the
              purposes of this application and potential employment.
            </>
          }
        />
      </div>

      <div style={{ marginTop: 28 }}>
        <Field
          label="Type your full legal name"
          required
          name="fullLegalName"
          value={signature.fullLegalName ?? ""}
          onChange={(v) => update({ fullLegalName: v })}
          hint="As it appears on your driver's license or government ID"
        />
      </div>

      <SignaturePad
        value={signature.signatureData ?? ""}
        onChange={(v) => update({ signatureData: v })}
      />

      {submitError && (
        <div
          style={{
            marginTop: 16,
            padding: "14px 18px",
            background: "#FDF1F0",
            border: "1px solid var(--apply-rose)",
            borderRadius: "var(--apply-r)",
            color: "var(--apply-rose)",
            fontSize: 13.5,
          }}
        >
          {submitError}
        </div>
      )}

      <div className="wizard-nav">
        <button type="button" className="btn btn-ghost" onClick={onPrev} disabled={submitting}>
          ← Back
        </button>
        <button
          type="button"
          className="btn btn-primary"
          onClick={handleSubmit}
          disabled={!canSubmit}
        >
          {submitting ? "Submitting…" : "Submit application"}
          {!submitting && <ArrowRight />}
        </button>
      </div>
    </>
  );
}

// ============================================================================
// Review block
// ============================================================================
function ApplicationReview({
  formData,
  roleName,
}: {
  formData: ApplicationData;
  roleName: string;
}) {
  const p = formData.personal ?? {};
  const wh = formData.workHistory?.entries ?? [];
  const ed = formData.education?.entries ?? [];
  const cert = formData.certifications?.entries ?? [];

  return (
    <div
      style={{
        background: "var(--apply-paper-soft)",
        border: "1px solid var(--apply-border)",
        borderRadius: "var(--apply-r-lg)",
        padding: "24px 28px",
      }}
    >
      <h3
        style={{
          fontSize: 12,
          fontWeight: 600,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          color: "var(--apply-ink-faint)",
          margin: "0 0 16px",
        }}
      >
        Review your application
      </h3>

      <ReviewLine label="Applying for">{roleName}</ReviewLine>
      <ReviewLine label="Name">
        {[p.firstName, p.middleName, p.lastName].filter(Boolean).join(" ") || "—"}
      </ReviewLine>
      <ReviewLine label="Email">{p.email ?? "—"}</ReviewLine>
      <ReviewLine label="Phone">{p.phone ?? "—"}</ReviewLine>
      <ReviewLine label="Location">
        {[p.address?.city, p.address?.state].filter(Boolean).join(", ") || "—"}
      </ReviewLine>
      <ReviewLine label="Work history">{wh.length} job{wh.length === 1 ? "" : "s"}</ReviewLine>
      <ReviewLine label="Education">{ed.length} school{ed.length === 1 ? "" : "s"}</ReviewLine>
      <ReviewLine label="Certifications">{cert.length}</ReviewLine>
    </div>
  );
}

function ReviewLine({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "140px 1fr",
        gap: 16,
        padding: "8px 0",
        borderBottom: "1px solid var(--apply-border)",
        fontSize: 14,
      }}
    >
      <span style={{ color: "var(--apply-ink-faint)", fontSize: 13 }}>{label}</span>
      <span style={{ color: "var(--apply-ink)", fontWeight: 500 }}>{children}</span>
    </div>
  );
}

// ============================================================================
// Agreement check
// ============================================================================
function AgreementBlock({
  checked,
  onChange,
  title,
  body,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  title: string;
  body: React.ReactNode;
}) {
  return (
    <label
      style={{
        display: "flex",
        gap: 14,
        padding: "16px 18px",
        background: checked ? "var(--apply-emerald-tint)" : "var(--apply-paper-soft)",
        border: `1px solid ${checked ? "var(--apply-emerald)" : "var(--apply-border)"}`,
        borderRadius: "var(--apply-r-lg)",
        cursor: "pointer",
        marginBottom: 12,
        transition: "all 0.2s var(--apply-ease)",
      }}
    >
      <CheckBox checked={checked} onChange={onChange} />
      <div>
        <div
          style={{
            fontWeight: 600,
            fontSize: 14,
            color: "var(--apply-ink)",
            marginBottom: 4,
          }}
        >
          {title}
        </div>
        <div
          style={{
            fontSize: 13.5,
            color: "var(--apply-ink-muted)",
            lineHeight: 1.55,
          }}
        >
          {body}
        </div>
      </div>
    </label>
  );
}

function CheckBox({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onChange(!checked);
      }}
      role="checkbox"
      aria-checked={checked}
      style={{
        width: 22,
        height: 22,
        minWidth: 22,
        borderRadius: 6,
        border: `1.5px solid ${checked ? "var(--apply-emerald)" : "var(--apply-border-strong)"}`,
        background: checked ? "var(--apply-emerald)" : "var(--apply-paper)",
        cursor: "pointer",
        marginTop: 2,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 0,
        transition: "all 0.15s var(--apply-ease)",
      }}
    >
      {checked && (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
          <path
            d="M2.5 6l2.5 2.5 4.5-5"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </button>
  );
}

// ============================================================================
// Signature pad
// ============================================================================
function SignaturePad({
  value,
  onChange,
}: {
  value: string;
  onChange: (data: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasInk, setHasInk] = useState(false);

  // Setup canvas on mount
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const setupCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.scale(dpr, dpr);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.lineWidth = 2.2;
      ctx.strokeStyle = "#1A1F1C";
    };

    setupCanvas();

    // Re-setup on resize
    const ro = new ResizeObserver(setupCanvas);
    ro.observe(canvas);
    return () => ro.disconnect();
  }, []);

  const getCoords = (e: React.MouseEvent | React.TouchEvent): { x: number; y: number } => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    if ("touches" in e) {
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top,
      };
    }
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const start = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsDrawing(true);
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const { x, y } = getCoords(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const { x, y } = getCoords(e);
    ctx.lineTo(x, y);
    ctx.stroke();
    if (!hasInk) setHasInk(true);
  };

  const end = useCallback(() => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas && hasInk) {
      onChange(canvas.toDataURL("image/png"));
    }
  }, [isDrawing, hasInk, onChange]);

  const clear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasInk(false);
    onChange("");
  };

  return (
    <div style={{ marginTop: 20 }}>
      <label className="field-label" style={{ marginBottom: 8, display: "block" }}>
        Sign here<span className="field-required">*</span>
      </label>
      <div
        style={{
          position: "relative",
          background: "var(--apply-paper)",
          border: `1.5px solid ${value ? "var(--apply-emerald)" : "var(--apply-border-strong)"}`,
          borderRadius: "var(--apply-r-lg)",
          overflow: "hidden",
          height: 180,
        }}
      >
        <canvas
          ref={canvasRef}
          style={{ width: "100%", height: "100%", touchAction: "none", cursor: "crosshair", display: "block" }}
          onMouseDown={start}
          onMouseMove={draw}
          onMouseUp={end}
          onMouseLeave={end}
          onTouchStart={start}
          onTouchMove={draw}
          onTouchEnd={end}
        />
        {!hasInk && !value && (
          <div
            style={{
              position: "absolute",
              inset: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              pointerEvents: "none",
              color: "var(--apply-ink-faint)",
              fontSize: 14,
              fontStyle: "italic",
            }}
          >
            Use your finger or mouse to sign
          </div>
        )}
        <div
          style={{
            position: "absolute",
            bottom: 12,
            right: 16,
            fontSize: 11,
            color: "var(--apply-ink-faint)",
            pointerEvents: "none",
          }}
        >
          × signature
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
        <span className="field-hint">By signing, you certify this application electronically.</span>
        {(hasInk || value) && (
          <button
            type="button"
            onClick={clear}
            style={{
              background: "transparent",
              border: "none",
              color: "var(--apply-ink-muted)",
              fontSize: 12.5,
              cursor: "pointer",
              fontWeight: 500,
              textDecoration: "underline",
              textUnderlineOffset: 3,
              padding: 0,
            }}
          >
            Clear
          </button>
        )}
      </div>
    </div>
  );
}

const inlineLink: React.CSSProperties = {
  color: "var(--apply-emerald-deep)",
  textDecoration: "underline",
  textUnderlineOffset: 3,
};

function ArrowRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path d="M3 7h8m-3-3l3 3-3 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
