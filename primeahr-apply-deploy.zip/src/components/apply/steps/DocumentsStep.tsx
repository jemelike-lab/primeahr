"use client";

import { useState, useRef, useCallback } from "react";
import type { ApplicationData } from "@/lib/apply/application-schema";

interface Props {
  role: {
    requiredDocuments: string[];
    optionalDocuments: string[];
  };
  applicationId: string | null;
  resumeToken: string | null;
  ensureApplication: () => Promise<{ applicationId: string; resumeToken: string }>;
  formData: ApplicationData;
  onChange: (patch: Partial<ApplicationData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

// Human-readable labels & descriptions for each doc type
const DOC_META: Record<string, { label: string; hint: string; icon: React.ReactNode }> = {
  drivers_license: {
    label: "Driver's license",
    hint: "Front of your current Maryland (or other state) license",
    icon: <CarIcon />,
  },
  ssn_card: {
    label: "Social Security card",
    hint: "We'll keep this encrypted — required for payroll/I-9",
    icon: <CardIcon />,
  },
  bachelors_diploma: {
    label: "Bachelor's degree diploma",
    hint: "Photo or PDF of your bachelor's degree",
    icon: <ScrollIcon />,
  },
  college_transcript: {
    label: "College transcript",
    hint: "Unofficial is fine for now — we'll request official later",
    icon: <ScrollIcon />,
  },
  diploma_or_ged: {
    label: "Diploma or GED",
    hint: "High school diploma or GED (for roles that don't require a bachelor's)",
    icon: <ScrollIcon />,
  },
  auto_insurance: {
    label: "Auto insurance card",
    hint: "Current declarations page or insurance card",
    icon: <CarIcon />,
  },
  professional_references: {
    label: "Professional references",
    hint: "Names, titles, and contact info — 2 to 3 references",
    icon: <CardIcon />,
  },
  pct_certification: {
    label: "Person-Centered Thinking certification",
    hint: "If you've completed PCT or similar — strong plus",
    icon: <BadgeIcon />,
  },
  case_management_cert: {
    label: "Case management certification",
    hint: "CCM, ACM, or other case management credentials",
    icon: <BadgeIcon />,
  },
  additional_certifications: {
    label: "Other certifications",
    hint: "Anything else relevant — MSW credentials, training certificates, etc.",
    icon: <BadgeIcon />,
  },
  background_check_consent: {
    label: "Background check consent",
    hint: "We'll provide this form during onboarding — no need to upload now",
    icon: <ShieldIcon />,
  },  },
};

interface UploadedDoc {
  docType: string;
  filename: string;
  storagePath: string;
  uploadedAt: string;
}

export function DocumentsStep({
  role,
  applicationId,
  resumeToken,
  ensureApplication,
  formData,
  onChange,
  onNext,
  onPrev,
}: Props) {
  const [uploads, setUploads] = useState<UploadedDoc[]>(() => {
    const types = formData.documents?.uploadedDocTypes ?? [];
    return types.map((t) => ({
      docType: t,
      filename: "Previously uploaded",
      storagePath: "",
      uploadedAt: new Date().toISOString(),
    }));
  });

  const uploadedTypes = new Set(uploads.map((u) => u.docType));

  const handleUpload = useCallback(
    async (docType: string, file: File) => {
      try {
        let appId = applicationId;
        let token = resumeToken;
        if (!appId || !token) {
          const created = await ensureApplication();
          appId = created.applicationId;
          token = created.resumeToken;
        }

        const form = new FormData();
        form.append("file", file);
        form.append("applicationId", appId);
        form.append("resumeToken", token);
        form.append("docType", docType);

        const res = await fetch("/api/apply/upload-document", {
          method: "POST",
          body: form,
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: "Upload failed" }));
          throw new Error(err.error ?? "Upload failed");
        }

        const data = await res.json();

        setUploads((prev) => {
          const filtered = prev.filter((p) => p.docType !== docType);
          const next = [
            ...filtered,
            {
              docType,
              filename: file.name,
              storagePath: data.storagePath,
              uploadedAt: new Date().toISOString(),
            },
          ];
          // Persist to form data
          onChange({
            documents: { uploadedDocTypes: next.map((u) => u.docType) },
          });
          return next;
        });
      } catch (e) {
        console.error("[DocumentsStep] upload failed:", e);
        alert(e instanceof Error ? e.message : "Upload failed");
      }
    },
    [applicationId, resumeToken, ensureApplication, onChange]
  );

  const requiredDocs = role.requiredDocuments ?? [];
  const optionalDocs = role.optionalDocuments ?? [];
  const requiredCount = requiredDocs.length;
  const requiredUploaded = requiredDocs.filter((d) => uploadedTypes.has(d)).length;
  const allRequiredDone = requiredUploaded === requiredCount;

  return (
    <>
      <div className="stage-header">
        <div className="stage-eyebrow">Step 4 of 6 · Documents</div>
        <h2 className="stage-title">Upload your documents.</h2>
        <p className="stage-sub">
          Snap a photo or upload a file. Everything stays encrypted, and our team is the
          only one who can see them. You can do this on your phone if you want — just
          email yourself this page's link.
        </p>
      </div>

      <ProgressPill done={requiredUploaded} total={requiredCount} label="required" />

      <SectionLabel>Required for this role</SectionLabel>
      <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 28 }}>
        {requiredDocs.map((docType) => (
          <DocTile
            key={docType}
            docType={docType}
            uploaded={uploads.find((u) => u.docType === docType)}
            onUpload={(file) => handleUpload(docType, file)}
          />
        ))}
      </div>

      {optionalDocs.length > 0 && (
        <>
          <SectionLabel>Helpful but optional</SectionLabel>
          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 28 }}>
            {optionalDocs.map((docType) => (
              <DocTile
                key={docType}
                docType={docType}
                uploaded={uploads.find((u) => u.docType === docType)}
                onUpload={(file) => handleUpload(docType, file)}
              />
            ))}
          </div>
        </>
      )}

      {!allRequiredDone && (
        <div
          style={{
            background: "var(--apply-cream-deeper)",
            border: "1px solid var(--apply-border)",
            borderRadius: "var(--apply-r)",
            padding: "14px 18px",
            fontSize: 13.5,
            color: "var(--apply-ink-muted)",
            marginBottom: 20,
          }}
        >
          <strong style={{ color: "var(--apply-ink-2)" }}>Heads up:</strong> you'll still
          be able to submit your application without all the required documents — we'll
          follow up with you on the missing ones. But uploading now means we can move
          forward faster.
        </div>
      )}

      <div className="wizard-nav">
        <button type="button" className="btn btn-ghost" onClick={onPrev}>
          ← Back
        </button>
        <button type="button" className="btn btn-primary" onClick={onNext}>
          Continue → eligibility
          <ArrowRight />
        </button>
      </div>
    </>
  );
}

// ============================================================================
// Document tile
// ============================================================================
function DocTile({
  docType,
  uploaded,
  onUpload,
}: {
  docType: string;
  uploaded: UploadedDoc | undefined;
  onUpload: (file: File) => Promise<void>;
}) {
  const meta = DOC_META[docType] ?? {
    label: docType.replace(/_/g, " "),
    hint: "",
    icon: <ScrollIcon />,
  };
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const isUploaded = !!uploaded;

  const handleFile = async (file: File) => {
    setUploading(true);
    try {
      await onUpload(file);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 16,
        padding: "16px 20px",
        background: isUploaded ? "var(--apply-emerald-tint)" : "var(--apply-paper-soft)",
        border: `1px solid ${isUploaded ? "var(--apply-emerald)" : "var(--apply-border)"}`,
        borderRadius: "var(--apply-r-lg)",
        transition: "all 0.2s var(--apply-ease)",
      }}
    >
      <div
        style={{
          width: 44,
          height: 44,
          borderRadius: 12,
          background: isUploaded ? "var(--apply-emerald)" : "var(--apply-paper)",
          color: isUploaded ? "var(--apply-paper)" : "var(--apply-emerald-deep)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          border: isUploaded ? "none" : "1px solid var(--apply-border)",
        }}
      >
        {isUploaded ? <CheckIcon /> : meta.icon}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14.5, color: "var(--apply-ink)" }}>
          {meta.label}
        </div>
        <div
          style={{
            fontSize: 12.5,
            color: "var(--apply-ink-muted)",
            marginTop: 2,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {isUploaded ? `Uploaded · ${uploaded?.filename}` : meta.hint}
        </div>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="image/*,.pdf"
        onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        style={{ display: "none" }}
      />
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        style={{ display: "none" }}
      />

      {isUploaded ? (
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          style={{
            background: "transparent",
            border: "none",
            fontSize: 13,
            fontWeight: 500,
            color: "var(--apply-emerald-deep)",
            cursor: "pointer",
            textDecoration: "underline",
            textUnderlineOffset: 3,
          }}
        >
          Replace
        </button>
      ) : (
        <div style={{ display: "flex", gap: 8 }}>
          <button
            type="button"
            onClick={() => cameraRef.current?.click()}
            disabled={uploading}
            style={tileBtn("ghost")}
            aria-label="Take photo"
          >
            <CameraIcon />
          </button>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            style={tileBtn("primary")}
          >
            {uploading ? "Uploading…" : "Upload"}
          </button>
        </div>
      )}
    </div>
  );
}

function tileBtn(variant: "primary" | "ghost"): React.CSSProperties {
  return {
    fontFamily: "inherit",
    fontSize: 13.5,
    fontWeight: 600,
    padding: "8px 14px",
    borderRadius: 100,
    cursor: "pointer",
    border:
      variant === "ghost"
        ? "1px solid var(--apply-border)"
        : "1px solid transparent",
    background: variant === "ghost" ? "var(--apply-paper)" : "var(--apply-ink)",
    color: variant === "ghost" ? "var(--apply-ink-2)" : "var(--apply-paper)",
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
  };
}

function ProgressPill({ done, total, label }: { done: number; total: number; label: string }) {
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 16px",
        background: done === total && total > 0 ? "var(--apply-emerald-tint)" : "var(--apply-cream-deeper)",
        color: done === total && total > 0 ? "var(--apply-emerald-deep)" : "var(--apply-ink-muted)",
        border: `1px solid ${done === total && total > 0 ? "var(--apply-emerald)" : "var(--apply-border)"}`,
        borderRadius: 100,
        fontSize: 12.5,
        fontWeight: 600,
        marginBottom: 20,
        transition: "all 0.3s var(--apply-ease)",
      }}
    >
      {done === total && total > 0 ? (
        <>
          <CheckIcon size={12} /> All {total} {label} documents uploaded
        </>
      ) : (
        <>
          {done} of {total} {label} documents uploaded
        </>
      )}
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <h3
      style={{
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: "var(--apply-ink-faint)",
        marginTop: 20,
        marginBottom: 12,
      }}
    >
      {children}
    </h3>
  );
}

// ============================================================================
// Icons
// ============================================================================
function CheckIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 18 18" fill="none" aria-hidden>
      <path d="M4 9.5L7.5 13 14 5.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function CameraIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden>
      <path d="M2 5h2l1-1.5h6L12 5h2v8H2V5z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <circle cx="8" cy="9" r="2.2" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}
function CarIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <path d="M3 13h14m-12-3l1-3h8l1 3M3 13h14v3H3v-3z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}
function CardIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <rect x="2" y="5" width="16" height="10" rx="1" stroke="currentColor" strokeWidth="1.5" />
      <path d="M2 9h16M5 12h3" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function ScrollIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <path d="M5 3h10v14H5z" stroke="currentColor" strokeWidth="1.5" />
      <path d="M7 7h6M7 10h6M7 13h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}
function BadgeIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <path d="M10 2l2 2h4v4l2 2-2 2v4h-4l-2 2-2-2H4v-4l-2-2 2-2V4h4l2-2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <circle cx="10" cy="10" r="2" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function HeartIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <path d="M10 16l-6-6c-2-2-1-5 1-6s4 0 5 2c1-2 3-3 5-2s3 4 1 6l-6 6z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}
function PillIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <rect x="3" y="7" width="14" height="6" rx="3" transform="rotate(-30 10 10)" stroke="currentColor" strokeWidth="1.5" />
      <path d="M6.5 6.5l6 6" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function ShieldIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <path d="M10 2l6 2v6c0 4-3 7-6 8-3-1-6-4-6-8V4l6-2z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}
function ArrowRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path d="M3 7h8m-3-3l3 3-3 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
