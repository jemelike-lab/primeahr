"use client";

import { useState, useEffect } from "react";
import type { ApplicationData } from "@/lib/apply/application-schema";
import { personalInfoSchema } from "@/lib/apply/application-schema";

interface Props {
  formData: ApplicationData;
  onChange: (patch: Partial<ApplicationData>) => void;
  onNext: () => void;
  onPrev: () => void;
  hasParsedResume: boolean;
  aiSummary: string;
}

const US_STATES = [
  "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI",
  "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN",
  "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
  "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA",
  "WV", "WI", "WY",
];

const REFERRAL_OPTIONS = [
  { value: "indeed", label: "Indeed" },
  { value: "linkedin", label: "LinkedIn" },
  { value: "facebook", label: "Facebook" },
  { value: "referral", label: "Referred by an employee" },
  { value: "google_search", label: "Google search" },
  { value: "career_fair", label: "Career fair" },
  { value: "walk_in", label: "Walked in / drove by" },
  { value: "other", label: "Other" },
];

export function PersonalInfoStep({
  formData,
  onChange,
  onNext,
  onPrev,
  hasParsedResume,
  aiSummary,
}: Props) {
  const personal = formData.personal ?? {};

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [prefilledFields, setPrefilledFields] = useState<Set<string>>(new Set());

  // Track which fields came from the parsed resume so we can badge them
  useEffect(() => {
    if (!hasParsedResume) return;
    const prefilled = new Set<string>();
    if (personal.firstName) prefilled.add("firstName");
    if (personal.lastName) prefilled.add("lastName");
    if (personal.email) prefilled.add("email");
    if (personal.phone) prefilled.add("phone");
    if (personal.address?.line1) prefilled.add("address");
    setPrefilledFields(prefilled);
    // We only do this on mount, intentionally
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasParsedResume]);

  const update = (patch: Partial<typeof personal>) => {
    onChange({ personal: { ...personal, ...patch } as ApplicationData["personal"] });
  };

  const updateAddress = (patch: Partial<NonNullable<typeof personal.address>>) => {
    update({
      address: {
        line1: personal.address?.line1 ?? "",
        line2: personal.address?.line2 ?? "",
        city: personal.address?.city ?? "",
        state: personal.address?.state ?? "",
        zip: personal.address?.zip ?? "",
        ...patch,
      },
    });
  };

  const handleContinue = () => {
    const result = personalInfoSchema.safeParse(personal);
    if (!result.success) {
      const flat = result.error.flatten();
      const fieldErrors: Record<string, string> = {};
      Object.entries(flat.fieldErrors).forEach(([key, val]) => {
        if (val && val[0]) fieldErrors[key] = val[0];
      });
      // Address sub-errors
      const addr = (flat.fieldErrors as Record<string, string[] | undefined>).address;
      if (addr && addr[0]) fieldErrors["address.line1"] = addr[0];
      setErrors(fieldErrors);
      // Focus first error
      const firstKey = Object.keys(fieldErrors)[0];
      if (firstKey) {
        const el = document.querySelector(`[data-field="${firstKey}"]`) as HTMLElement;
        el?.focus();
        el?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      return;
    }
    setErrors({});
    onNext();
  };

  return (
    <>
      <div className="stage-header">
        <div className="stage-eyebrow">Step 2 of 6 · About you</div>
        <h2 className="stage-title">
          {hasParsedResume ? "Quick — does this look right?" : "Tell us about yourself."}
        </h2>
        <p className="stage-sub">
          {hasParsedResume
            ? "We pulled these details from your resume. Make any corrections and add anything that's missing."
            : "Just the basics so we can stay in touch about your application."}
        </p>
      </div>

      {hasParsedResume && aiSummary && (
        <div className="ai-summary">
          <div className="ai-summary-eyebrow">
            <SparkleIcon /> What we saw in your resume
          </div>
          <p className="ai-summary-text">{aiSummary}</p>
        </div>
      )}

      <div className="form-grid">
        <Field
          label="First name"
          required
          name="firstName"
          value={personal.firstName ?? ""}
          onChange={(v) => update({ firstName: v })}
          error={errors.firstName}
          prefilled={prefilledFields.has("firstName")}
        />
        <Field
          label="Last name"
          required
          name="lastName"
          value={personal.lastName ?? ""}
          onChange={(v) => update({ lastName: v })}
          error={errors.lastName}
          prefilled={prefilledFields.has("lastName")}
        />

        <Field
          label="Middle name"
          name="middleName"
          value={personal.middleName ?? ""}
          onChange={(v) => update({ middleName: v })}
          hint="Optional"
        />
        <Field
          label="Preferred name"
          name="preferredName"
          value={personal.preferredName ?? ""}
          onChange={(v) => update({ preferredName: v })}
          hint="What we'll call you"
        />

        <Field
          label="Email"
          required
          type="email"
          name="email"
          value={personal.email ?? ""}
          onChange={(v) => update({ email: v })}
          error={errors.email}
          prefilled={prefilledFields.has("email")}
          hint="We'll send updates here"
        />
        <Field
          label="Phone"
          required
          type="tel"
          name="phone"
          value={personal.phone ?? ""}
          onChange={(v) => update({ phone: v })}
          error={errors.phone}
          prefilled={prefilledFields.has("phone")}
          placeholder="(301) 555-0142"
        />

        <div className="form-grid-full">
          <SectionDivider label="Address" />
        </div>

        <div className="form-grid-full">
          <Field
            label="Street address"
            required
            name="address.line1"
            value={personal.address?.line1 ?? ""}
            onChange={(v) => updateAddress({ line1: v })}
            error={errors["address.line1"]}
            prefilled={prefilledFields.has("address")}
          />
        </div>
        <div className="form-grid-full">
          <Field
            label="Apt, suite, unit (optional)"
            name="address.line2"
            value={personal.address?.line2 ?? ""}
            onChange={(v) => updateAddress({ line2: v })}
          />
        </div>

        <Field
          label="City"
          required
          name="address.city"
          value={personal.address?.city ?? ""}
          onChange={(v) => updateAddress({ city: v })}
        />

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 12 }}>
          <SelectField
            label="State"
            required
            name="address.state"
            value={personal.address?.state ?? ""}
            onChange={(v) => updateAddress({ state: v })}
            options={US_STATES.map((s) => ({ value: s, label: s }))}
            placeholder="—"
          />
          <Field
            label="ZIP"
            required
            name="address.zip"
            value={personal.address?.zip ?? ""}
            onChange={(v) => updateAddress({ zip: v })}
            placeholder="20785"
          />
        </div>

        <div className="form-grid-full">
          <SectionDivider label="A few quick questions" />
        </div>

        <div className="form-grid-full">
          <YesNoField
            label="Are you legally authorized to work in the United States?"
            value={personal.authorizedToWorkInUS}
            onChange={(v) => update({ authorizedToWorkInUS: v })}
            required
          />
        </div>

        <div className="form-grid-full">
          <YesNoField
            label="Will you now or in the future require sponsorship for employment?"
            value={personal.requiresSponsorship}
            onChange={(v) => update({ requiresSponsorship: v })}
            required
          />
        </div>

        <div className="form-grid-full">
          <SelectField
            label="How did you hear about us?"
            name="referralSource"
            value={personal.referralSource ?? ""}
            onChange={(v) => update({ referralSource: v as typeof personal.referralSource })}
            options={REFERRAL_OPTIONS}
            placeholder="Select an option"
          />
        </div>

        {personal.referralSource === "referral" && (
          <div className="form-grid-full">
            <Field
              label="Who referred you?"
              name="referrerName"
              value={personal.referrerName ?? ""}
              onChange={(v) => update({ referrerName: v })}
              hint="Full name of the employee who referred you"
            />
          </div>
        )}
      </div>

      <div className="wizard-nav">
        <button type="button" className="btn btn-ghost" onClick={onPrev}>
          ← Back
        </button>
        <button type="button" className="btn btn-primary" onClick={handleContinue}>
          Continue → experience
          <ArrowRight />
        </button>
      </div>
    </>
  );
}

// ============================================================================
// Reusable field components
// ============================================================================

interface FieldProps {
  label: string;
  name: string;
  value: string;
  onChange: (val: string) => void;
  type?: string;
  required?: boolean;
  error?: string;
  hint?: string;
  placeholder?: string;
  prefilled?: boolean;
}

export function Field({
  label,
  name,
  value,
  onChange,
  type = "text",
  required,
  error,
  hint,
  placeholder,
  prefilled,
}: FieldProps) {
  return (
    <div className="field">
      <label className="field-label" htmlFor={`field-${name}`}>
        {label}
        {required && <span className="field-required">*</span>}
        {prefilled && (
          <span className="field-prefill" style={{ marginLeft: 8 }}>
            <SparkleIcon size={10} /> From your resume
          </span>
        )}
      </label>
      <input
        id={`field-${name}`}
        data-field={name}
        type={type}
        className="field-input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-invalid={!!error}
        aria-describedby={error ? `${name}-error` : hint ? `${name}-hint` : undefined}
      />
      {error && (
        <span className="field-error" id={`${name}-error`}>
          <ErrorIcon /> {error}
        </span>
      )}
      {!error && hint && (
        <span className="field-hint" id={`${name}-hint`}>
          {hint}
        </span>
      )}
    </div>
  );
}

interface SelectFieldProps {
  label: string;
  name: string;
  value: string;
  onChange: (val: string) => void;
  options: Array<{ value: string; label: string }>;
  required?: boolean;
  error?: string;
  hint?: string;
  placeholder?: string;
}

export function SelectField({
  label,
  name,
  value,
  onChange,
  options,
  required,
  error,
  hint,
  placeholder,
}: SelectFieldProps) {
  return (
    <div className="field">
      <label className="field-label" htmlFor={`field-${name}`}>
        {label}
        {required && <span className="field-required">*</span>}
      </label>
      <select
        id={`field-${name}`}
        data-field={name}
        className="field-select"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      {error && (
        <span className="field-error">
          <ErrorIcon /> {error}
        </span>
      )}
      {!error && hint && <span className="field-hint">{hint}</span>}
    </div>
  );
}

interface YesNoFieldProps {
  label: string;
  value: boolean | undefined;
  onChange: (val: boolean) => void;
  required?: boolean;
  error?: string;
}

export function YesNoField({ label, value, onChange, required, error }: YesNoFieldProps) {
  return (
    <div className="field">
      <label className="field-label">
        {label}
        {required && <span className="field-required">*</span>}
      </label>
      <div style={{ display: "flex", gap: 8 }}>
        <button
          type="button"
          onClick={() => onChange(true)}
          className="yesno-btn"
          data-active={value === true}
          style={yesNoStyle(value === true)}
        >
          Yes
        </button>
        <button
          type="button"
          onClick={() => onChange(false)}
          className="yesno-btn"
          data-active={value === false}
          style={yesNoStyle(value === false)}
        >
          No
        </button>
      </div>
      {error && (
        <span className="field-error">
          <ErrorIcon /> {error}
        </span>
      )}
    </div>
  );
}

function yesNoStyle(active: boolean): React.CSSProperties {
  return {
    flex: 1,
    fontFamily: "inherit",
    fontSize: 14,
    fontWeight: 500,
    padding: "11px 16px",
    borderRadius: "var(--apply-r-sm)",
    border: `1.5px solid ${active ? "var(--apply-emerald)" : "var(--apply-border)"}`,
    background: active ? "var(--apply-emerald-tint)" : "var(--apply-paper-soft)",
    color: active ? "var(--apply-emerald-deep)" : "var(--apply-ink-2)",
    cursor: "pointer",
    transition: "all 0.18s var(--apply-ease)",
  };
}

export function SectionDivider({ label }: { label: string }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        marginTop: 20,
        marginBottom: 4,
      }}
    >
      <span
        style={{
          fontSize: 12,
          fontWeight: 600,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          color: "var(--apply-ink-faint)",
        }}
      >
        {label}
      </span>
      <span style={{ flex: 1, height: 1, background: "var(--apply-border)" }} />
    </div>
  );
}

function SparkleIcon({ size = 12 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 12 12" fill="none" aria-hidden>
      <path d="M6 1l1.2 3.1L10.3 5.5 7.7 7 8.5 10.3 6 8.5 3.5 10.3 4.3 7 1.7 5.5 4.8 4.1z" fill="currentColor" />
    </svg>
  );
}

function ErrorIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
      <circle cx="6" cy="6" r="5" stroke="currentColor" strokeWidth="1.4" />
      <path d="M6 3.5v3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="6" cy="8.5" r="0.7" fill="currentColor" />
    </svg>
  );
}

function ArrowRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path d="M3 7h8m-3-3l3 3-3 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
