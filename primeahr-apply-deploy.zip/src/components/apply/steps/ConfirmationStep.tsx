"use client";

interface Props {
  role: { displayName: string };
  aiSummary: string;
}

export function ConfirmationStep({ role, aiSummary }: Props) {
  return (
    <div className="wizard-shell">
      <div
        style={{
          maxWidth: 720,
          margin: "0 auto",
          padding: "40px 32px",
          textAlign: "center",
          animation: "fade-up 0.8s var(--apply-ease) both",
        }}
      >
        <div
          style={{
            width: 96,
            height: 96,
            margin: "0 auto 28px",
            borderRadius: "50%",
            background: "linear-gradient(135deg, var(--apply-emerald) 0%, var(--apply-emerald-light) 100%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--apply-paper)",
            boxShadow: "0 20px 60px -10px rgba(14, 124, 102, 0.4)",
            animation: "check-pop 0.6s var(--apply-ease-bounce) both",
          }}
        >
          <CheckIcon size={44} />
        </div>

        <h1
          style={{
            fontFamily: "var(--apply-font-display)",
            fontSize: "clamp(36px, 5vw, 54px)",
            fontWeight: 400,
            fontVariationSettings: "'opsz' 144",
            color: "var(--apply-ink)",
            letterSpacing: "-0.025em",
            lineHeight: 1.05,
            margin: "0 0 16px",
          }}
        >
          Application submitted.
        </h1>

        <p
          style={{
            fontSize: 18,
            color: "var(--apply-ink-muted)",
            lineHeight: 1.55,
            maxWidth: 540,
            margin: "0 auto 32px",
          }}
        >
          Thanks for applying for the <strong style={{ color: "var(--apply-ink)" }}>{role.displayName}</strong>{" "}
          role. We've sent a confirmation to the email you provided. Our team will review
          your application within 2 business days.
        </p>

        {aiSummary && (
          <div
            className="ai-summary"
            style={{ textAlign: "left", margin: "0 auto 32px", maxWidth: 600 }}
          >
            <div className="ai-summary-eyebrow">
              <SparkleIcon /> What we'll share with our team
            </div>
            <p className="ai-summary-text">{aiSummary}</p>
          </div>
        )}

        <div
          style={{
            background: "var(--apply-paper-soft)",
            border: "1px solid var(--apply-border)",
            borderRadius: "var(--apply-r-lg)",
            padding: "28px 32px",
            textAlign: "left",
            maxWidth: 600,
            margin: "0 auto 28px",
          }}
        >
          <h3
            style={{
              fontFamily: "var(--apply-font-display)",
              fontSize: 20,
              fontWeight: 500,
              margin: "0 0 16px",
              color: "var(--apply-ink)",
            }}
          >
            What happens next
          </h3>
          <NextStep
            num="1"
            title="A coordinator reviews your application"
            body="Usually within 1–2 business days. We'll match you against open requisitions and check for any missing information."
          />
          <NextStep
            num="2"
            title="Phone screen invitation"
            body="If there's a fit, you'll get a calendar link to book a 15-minute call with our team. Be ready to talk about your experience and ask questions."
          />
          <NextStep
            num="3"
            title="In-person or virtual interview"
            body="Meet your potential supervisor and learn more about how the role works at BLH. For Support Planner and CCS roles, we'll talk through how we coordinate services for participants in CFC and DDA waiver programs."
          />
          <NextStep
            num="4"
            title="Offer & onboarding"
            body="If we're a match, you'll receive a digital offer letter on your phone. Once signed, our onboarding system walks you through the rest — document uploads, background check, paperwork — and gets you ready for day one."
            isLast
          />
        </div>

        <p style={{ fontSize: 13.5, color: "var(--apply-ink-faint)", margin: "0 0 20px" }}>
          Questions? Email{" "}
          <a
            href="mailto:careers@beatricelovingheart.com"
            style={{ color: "var(--apply-emerald-deep)", textDecoration: "underline" }}
          >
            careers@beatricelovingheart.com
          </a>
        </p>

        <a
          href="/"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            fontSize: 14,
            fontWeight: 600,
            color: "var(--apply-ink-2)",
            textDecoration: "none",
            padding: "10px 20px",
            borderRadius: 100,
            border: "1px solid var(--apply-border)",
            background: "var(--apply-paper)",
          }}
        >
          ← Back to careers page
        </a>
      </div>

      <style jsx>{`
        @keyframes check-pop {
          0% {
            opacity: 0;
            transform: scale(0.5);
          }
          70% {
            transform: scale(1.1);
          }
          100% {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  );
}

function NextStep({
  num,
  title,
  body,
  isLast,
}: {
  num: string;
  title: string;
  body: string;
  isLast?: boolean;
}) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "32px 1fr",
        gap: 14,
        paddingBottom: isLast ? 0 : 18,
        marginBottom: isLast ? 0 : 18,
        borderBottom: isLast ? "none" : "1px solid var(--apply-border)",
      }}
    >
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: "50%",
          background: "var(--apply-emerald-tint)",
          color: "var(--apply-emerald-deep)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: 700,
          fontSize: 13,
          marginTop: 1,
        }}
      >
        {num}
      </div>
      <div>
        <div style={{ fontWeight: 600, fontSize: 15, color: "var(--apply-ink)", marginBottom: 4 }}>
          {title}
        </div>
        <div style={{ fontSize: 14, color: "var(--apply-ink-muted)", lineHeight: 1.55 }}>
          {body}
        </div>
      </div>
    </div>
  );
}

function CheckIcon({ size = 44 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 44 44" fill="none" aria-hidden>
      <path
        d="M10 22l8 8 16-18"
        stroke="currentColor"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function SparkleIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
      <path d="M6 1l1.2 3.1L10.3 5.5 7.7 7 8.5 10.3 6 8.5 3.5 10.3 4.3 7 1.7 5.5 4.8 4.1z" fill="currentColor" />
    </svg>
  );
}
