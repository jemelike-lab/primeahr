"use client";

import type { ApplicationData } from "@/lib/apply/application-schema";
import { Field, SectionDivider, YesNoField } from "./PersonalInfoStep";

interface Props {
  formData: ApplicationData;
  onChange: (patch: Partial<ApplicationData>) => void;
  onNext: () => void;
  onPrev: () => void;
  hasParsedResume: boolean;
}

type WorkEntry = NonNullable<NonNullable<ApplicationData["workHistory"]>["entries"]>[number];
type EduEntry = NonNullable<NonNullable<ApplicationData["education"]>["entries"]>[number];
type CertEntry = NonNullable<NonNullable<ApplicationData["certifications"]>["entries"]>[number];

const EDUCATION_LEVELS = [
  { value: "less_than_high_school", label: "Less than high school" },
  { value: "high_school", label: "High school diploma" },
  { value: "ged", label: "GED" },
  { value: "some_college", label: "Some college" },
  { value: "associates", label: "Associate's degree" },
  { value: "bachelors", label: "Bachelor's degree" },
  { value: "masters", label: "Master's degree" },
  { value: "doctorate", label: "Doctorate" },
  { value: "other", label: "Other" },
];

export function ExperienceStep({
  formData,
  onChange,
  onNext,
  onPrev,
  hasParsedResume,
}: Props) {
  const workHistory = formData.workHistory ?? {};
  const education = formData.education ?? {};
  const certifications = formData.certifications ?? {};

  const workEntries: WorkEntry[] = workHistory.entries ?? [];
  const eduEntries: EduEntry[] = education.entries ?? [];
  const certEntries: CertEntry[] = certifications.entries ?? [];

  // ===== Work history handlers =====
  const updateWork = (patch: Partial<NonNullable<ApplicationData["workHistory"]>>) => {
    onChange({
      workHistory: {
        ...workHistory,
        entries: workEntries,
        ...patch,
      },
    });
  };

  const updateWorkEntry = (idx: number, patch: Partial<WorkEntry>) => {
    const next = workEntries.map((e, i) => (i === idx ? { ...e, ...patch } : e));
    updateWork({ entries: next });
  };

  const addWorkEntry = () => {
    updateWork({
      entries: [
        ...workEntries,
        {
          employer: "",
          jobTitle: "",
          city: "",
          state: "",
          startDate: "",
          endDate: "",
          isCurrent: false,
          responsibilities: "",
          mayContactSupervisor: true,
        },
      ],
    });
  };

  const removeWorkEntry = (idx: number) => {
    updateWork({ entries: workEntries.filter((_, i) => i !== idx) });
  };

  // ===== Education handlers =====
  const updateEdu = (patch: Partial<NonNullable<ApplicationData["education"]>>) => {
    onChange({
      education: { ...education, entries: eduEntries, ...patch },
    });
  };

  const updateEduEntry = (idx: number, patch: Partial<EduEntry>) => {
    const next = eduEntries.map((e, i) => (i === idx ? { ...e, ...patch } : e));
    updateEdu({ entries: next });
  };

  const addEduEntry = () => {
    updateEdu({
      entries: [
        ...eduEntries,
        {
          institutionName: "",
          degree: "",
          fieldOfStudy: "",
          city: "",
          state: "",
          graduationDate: "",
          isCompleted: true,
        },
      ],
    });
  };

  const removeEduEntry = (idx: number) => {
    updateEdu({ entries: eduEntries.filter((_, i) => i !== idx) });
  };

  // ===== Certifications handlers =====
  const updateCerts = (patch: Partial<NonNullable<ApplicationData["certifications"]>>) => {
    onChange({
      certifications: { ...certifications, entries: certEntries, ...patch },
    });
  };

  const updateCertEntry = (idx: number, patch: Partial<CertEntry>) => {
    const next = certEntries.map((c, i) => (i === idx ? { ...c, ...patch } : c));
    updateCerts({ entries: next });
  };

  const addCertEntry = () => {
    updateCerts({
      entries: [
        ...certEntries,
        {
          name: "",
          issuingOrganization: "",
          licenseNumber: "",
          issuedDate: "",
          expirationDate: "",
          state: "",
          isActive: true,
        },
      ],
      hasNoCertifications: false,
    });
  };

  const removeCertEntry = (idx: number) => {
    updateCerts({ entries: certEntries.filter((_, i) => i !== idx) });
  };

  return (
    <>
      <div className="stage-header">
        <div className="stage-eyebrow">Step 3 of 6 · Experience</div>
        <h2 className="stage-title">
          {hasParsedResume
            ? "Here's what we found. Edit anything that's off."
            : "Walk us through your background."}
        </h2>
        <p className="stage-sub">
          Add your work history, education, and any certifications or licenses. We don't
          need everything from 20 years ago — just what's relevant.
        </p>
      </div>

      {/* ===== Work History ===== */}
      <SectionDivider label="Work history" />

      {workEntries.length === 0 ? (
        <EmptyState
          icon={<BriefcaseIcon />}
          message="No work history yet."
          actionLabel="+ Add a job"
          onAction={addWorkEntry}
        />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 20 }}>
          {workEntries.map((entry, idx) => (
            <WorkEntryCard
              key={idx}
              idx={idx}
              entry={entry}
              prefilled={hasParsedResume && idx < workEntries.length}
              onChange={(patch) => updateWorkEntry(idx, patch)}
              onRemove={() => removeWorkEntry(idx)}
            />
          ))}
          <button type="button" className="btn btn-secondary" onClick={addWorkEntry} style={{ alignSelf: "flex-start" }}>
            + Add another job
          </button>
        </div>
      )}

      <div style={{ marginTop: 16, marginBottom: 20 }}>
        <YesNoField
          label="Are there gaps of 6+ months in your work history?"
          value={workHistory.hasEmploymentGaps}
          onChange={(v) => updateWork({ hasEmploymentGaps: v })}
        />
        {workHistory.hasEmploymentGaps && (
          <div style={{ marginTop: 12 }}>
            <Field
              label="Briefly explain (optional)"
              name="gapExplanation"
              value={workHistory.gapExplanation ?? ""}
              onChange={(v) => updateWork({ gapExplanation: v })}
              hint="Caregiving, education, military service — whatever you'd like to share"
            />
          </div>
        )}
      </div>

      {/* ===== Education ===== */}
      <SectionDivider label="Education" />

      <div style={{ marginTop: 16, marginBottom: 16 }}>
        <SelectFieldStandalone
          label="Highest level completed"
          required
          value={education.highestLevelCompleted ?? ""}
          onChange={(v) => updateEdu({ highestLevelCompleted: v as NonNullable<ApplicationData["education"]>["highestLevelCompleted"] })}
          options={EDUCATION_LEVELS}
          placeholder="Select"
        />
      </div>

      {eduEntries.length === 0 ? (
        <EmptyState
          icon={<SchoolIcon />}
          message="No schools added yet."
          actionLabel="+ Add a school"
          onAction={addEduEntry}
        />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 20 }}>
          {eduEntries.map((entry, idx) => (
            <EduEntryCard
              key={idx}
              entry={entry}
              prefilled={hasParsedResume && idx < eduEntries.length}
              onChange={(patch) => updateEduEntry(idx, patch)}
              onRemove={() => removeEduEntry(idx)}
            />
          ))}
          <button type="button" className="btn btn-secondary" onClick={addEduEntry} style={{ alignSelf: "flex-start" }}>
            + Add another school
          </button>
        </div>
      )}

      {/* ===== Certifications ===== */}
      <SectionDivider label="Certifications & licenses" />

      <div style={{ marginTop: 12, marginBottom: 16 }}>
        <YesNoField
          label="Do you have any professional certifications or licenses? (PCT, CCM, MSW, Case Management, etc.)"
          value={!certifications.hasNoCertifications}
          onChange={(v) => updateCerts({ hasNoCertifications: !v })}
        />
      </div>

      {!certifications.hasNoCertifications && (
        <>
          {certEntries.length === 0 ? (
            <EmptyState
              icon={<AwardIcon />}
              message="No certifications added yet."
              actionLabel="+ Add a certification"
              onAction={addCertEntry}
            />
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 16, marginBottom: 20 }}>
              {certEntries.map((entry, idx) => (
                <CertEntryCard
                  key={idx}
                  entry={entry}
                  prefilled={hasParsedResume && idx < certEntries.length}
                  onChange={(patch) => updateCertEntry(idx, patch)}
                  onRemove={() => removeCertEntry(idx)}
                />
              ))}
              <button
                type="button"
                className="btn btn-secondary"
                onClick={addCertEntry}
                style={{ alignSelf: "flex-start" }}
              >
                + Add another certification
              </button>
            </div>
          )}
        </>
      )}

      <div className="wizard-nav">
        <button type="button" className="btn btn-ghost" onClick={onPrev}>
          ← Back
        </button>
        <button type="button" className="btn btn-primary" onClick={onNext}>
          Continue → documents
          <ArrowRight />
        </button>
      </div>
    </>
  );
}

// ============================================================================
// Entry cards
// ============================================================================

function WorkEntryCard({
  idx,
  entry,
  prefilled,
  onChange,
  onRemove,
}: {
  idx: number;
  entry: WorkEntry;
  prefilled: boolean;
  onChange: (patch: Partial<WorkEntry>) => void;
  onRemove: () => void;
}) {
  return (
    <div style={cardStyle}>
      <div style={cardHeaderStyle}>
        <span style={cardHeaderTextStyle}>
          Job #{idx + 1}
          {prefilled && (
            <span className="field-prefill" style={{ marginLeft: 8 }}>
              <SparkleIcon size={10} /> From your resume
            </span>
          )}
        </span>
        <button type="button" onClick={onRemove} style={removeBtnStyle} aria-label="Remove job">
          <TrashIcon />
        </button>
      </div>

      <div className="form-grid">
        <Field
          label="Employer"
          required
          name={`work-employer-${idx}`}
          value={entry.employer ?? ""}
          onChange={(v) => onChange({ employer: v })}
        />
        <Field
          label="Job title"
          required
          name={`work-title-${idx}`}
          value={entry.jobTitle ?? ""}
          onChange={(v) => onChange({ jobTitle: v })}
        />

        <Field
          label="City"
          name={`work-city-${idx}`}
          value={entry.city ?? ""}
          onChange={(v) => onChange({ city: v })}
        />
        <Field
          label="State"
          name={`work-state-${idx}`}
          value={entry.state ?? ""}
          onChange={(v) => onChange({ state: v })}
          placeholder="MD"
        />

        <Field
          label="Start date"
          required
          type="month"
          name={`work-start-${idx}`}
          value={entry.startDate ?? ""}
          onChange={(v) => onChange({ startDate: v })}
        />
        <Field
          label="End date"
          type="month"
          name={`work-end-${idx}`}
          value={entry.isCurrent ? "" : entry.endDate ?? ""}
          onChange={(v) => onChange({ endDate: v })}
          hint={entry.isCurrent ? "—" : "Leave blank if current"}
        />

        <div className="form-grid-full">
          <YesNoField
            label="Are you currently working here?"
            value={entry.isCurrent}
            onChange={(v) => onChange({ isCurrent: v, endDate: v ? "" : entry.endDate })}
          />
        </div>

        <div className="form-grid-full">
          <Field
            label="Key responsibilities"
            name={`work-resp-${idx}`}
            value={entry.responsibilities ?? ""}
            onChange={(v) => onChange({ responsibilities: v })}
            hint="A short summary. We don't need every detail."
          />
        </div>

        {!entry.isCurrent && (
          <>
            <Field
              label="Supervisor name"
              name={`work-sup-${idx}`}
              value={entry.supervisorName ?? ""}
              onChange={(v) => onChange({ supervisorName: v })}
              hint="Optional"
            />
            <Field
              label="Supervisor phone"
              type="tel"
              name={`work-supphone-${idx}`}
              value={entry.supervisorPhone ?? ""}
              onChange={(v) => onChange({ supervisorPhone: v })}
              hint="Optional"
            />
          </>
        )}
      </div>
    </div>
  );
}

function EduEntryCard({
  entry,
  prefilled,
  onChange,
  onRemove,
}: {
  entry: EduEntry;
  prefilled: boolean;
  onChange: (patch: Partial<EduEntry>) => void;
  onRemove: () => void;
}) {
  return (
    <div style={cardStyle}>
      <div style={cardHeaderStyle}>
        <span style={cardHeaderTextStyle}>
          School
          {prefilled && (
            <span className="field-prefill" style={{ marginLeft: 8 }}>
              <SparkleIcon size={10} /> From your resume
            </span>
          )}
        </span>
        <button type="button" onClick={onRemove} style={removeBtnStyle}>
          <TrashIcon />
        </button>
      </div>

      <div className="form-grid">
        <div className="form-grid-full">
          <Field
            label="School / institution name"
            required
            name="institutionName"
            value={entry.institutionName ?? ""}
            onChange={(v) => onChange({ institutionName: v })}
          />
        </div>
        <Field
          label="Degree"
          name="degree"
          value={entry.degree ?? ""}
          onChange={(v) => onChange({ degree: v })}
          placeholder="HS Diploma, Bachelor's, etc."
        />
        <Field
          label="Field of study"
          name="fieldOfStudy"
          value={entry.fieldOfStudy ?? ""}
          onChange={(v) => onChange({ fieldOfStudy: v })}
          hint="Optional"
        />
        <Field
          label="City"
          name="city"
          value={entry.city ?? ""}
          onChange={(v) => onChange({ city: v })}
        />
        <Field
          label="State"
          name="state"
          value={entry.state ?? ""}
          onChange={(v) => onChange({ state: v })}
        />
        <Field
          label="Graduation date"
          type="month"
          name="graduationDate"
          value={entry.graduationDate ?? ""}
          onChange={(v) => onChange({ graduationDate: v })}
          hint={entry.isCompleted ? undefined : "Expected"}
        />
        <div className="form-grid-full">
          <YesNoField
            label="Did you complete this program?"
            value={entry.isCompleted}
            onChange={(v) => onChange({ isCompleted: v })}
          />
        </div>
      </div>
    </div>
  );
}

function CertEntryCard({
  entry,
  prefilled,
  onChange,
  onRemove,
}: {
  entry: CertEntry;
  prefilled: boolean;
  onChange: (patch: Partial<CertEntry>) => void;
  onRemove: () => void;
}) {
  return (
    <div style={cardStyle}>
      <div style={cardHeaderStyle}>
        <span style={cardHeaderTextStyle}>
          Certification
          {prefilled && (
            <span className="field-prefill" style={{ marginLeft: 8 }}>
              <SparkleIcon size={10} /> From your resume
            </span>
          )}
        </span>
        <button type="button" onClick={onRemove} style={removeBtnStyle}>
          <TrashIcon />
        </button>
      </div>

      <div className="form-grid">
        <Field
          label="Certification name"
          required
          name="cert-name"
          value={entry.name ?? ""}
          onChange={(v) => onChange({ name: v })}
          placeholder="PCT, CCM, MSW, etc."
        />
        <Field
          label="Issuing organization"
          name="cert-issuer"
          value={entry.issuingOrganization ?? ""}
          onChange={(v) => onChange({ issuingOrganization: v })}
        />
        <Field
          label="License #"
          name="cert-num"
          value={entry.licenseNumber ?? ""}
          onChange={(v) => onChange({ licenseNumber: v })}
          hint="Optional — we'll verify later"
        />
        <Field
          label="State"
          name="cert-state"
          value={entry.state ?? ""}
          onChange={(v) => onChange({ state: v })}
          placeholder="MD"
        />
        <Field
          label="Issued"
          type="month"
          name="cert-issued"
          value={entry.issuedDate ?? ""}
          onChange={(v) => onChange({ issuedDate: v })}
        />
        <Field
          label="Expires"
          type="month"
          name="cert-exp"
          value={entry.expirationDate ?? ""}
          onChange={(v) => onChange({ expirationDate: v })}
          hint={entry.expirationDate ? undefined : "Leave blank if no expiration"}
        />
      </div>
    </div>
  );
}

// ============================================================================
// Helpers
// ============================================================================

function EmptyState({
  icon,
  message,
  actionLabel,
  onAction,
}: {
  icon: React.ReactNode;
  message: string;
  actionLabel: string;
  onAction: () => void;
}) {
  return (
    <div
      style={{
        border: "1px dashed var(--apply-border-strong)",
        borderRadius: "var(--apply-r-lg)",
        padding: "32px 24px",
        textAlign: "center",
        background: "var(--apply-paper-soft)",
        marginBottom: 16,
      }}
    >
      <div
        style={{
          width: 44,
          height: 44,
          margin: "0 auto 12px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "var(--apply-cream-deeper)",
          color: "var(--apply-ink-muted)",
          borderRadius: 10,
        }}
      >
        {icon}
      </div>
      <p style={{ fontSize: 14, color: "var(--apply-ink-muted)", margin: "0 0 16px" }}>{message}</p>
      <button type="button" className="btn btn-secondary" onClick={onAction}>
        {actionLabel}
      </button>
    </div>
  );
}

function SelectFieldStandalone({
  label,
  value,
  onChange,
  options,
  required,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: Array<{ value: string; label: string }>;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <div className="field" style={{ maxWidth: 360 }}>
      <label className="field-label">
        {label}
        {required && <span className="field-required">*</span>}
      </label>
      <select className="field-select" value={value} onChange={(e) => onChange(e.target.value)}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

const cardStyle: React.CSSProperties = {
  background: "var(--apply-paper-soft)",
  border: "1px solid var(--apply-border)",
  borderRadius: "var(--apply-r-lg)",
  padding: "24px 24px 20px",
};

const cardHeaderStyle: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  marginBottom: 16,
};

const cardHeaderTextStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 600,
  letterSpacing: "0.06em",
  textTransform: "uppercase",
  color: "var(--apply-ink-muted)",
};

const removeBtnStyle: React.CSSProperties = {
  background: "none",
  border: "none",
  color: "var(--apply-ink-faint)",
  cursor: "pointer",
  padding: 6,
  borderRadius: 6,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

// Icons
function BriefcaseIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <rect x="3" y="6" width="14" height="10" rx="1" stroke="currentColor" strokeWidth="1.5" />
      <path d="M7 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function SchoolIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <path d="M10 3l8 4-8 4-8-4 8-4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M5 8v5c0 1.5 2.5 3 5 3s5-1.5 5-3V8" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function AwardIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden>
      <circle cx="10" cy="8" r="5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M7 12l-2 5 3-1.5L10 17l2-1.5L15 17l-2-5" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden>
      <path d="M3 5h10M6 5V3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5V5m1 0v8a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function SparkleIcon({ size = 12 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 12 12" fill="none" aria-hidden>
      <path d="M6 1l1.2 3.1L10.3 5.5 7.7 7 8.5 10.3 6 8.5 3.5 10.3 4.3 7 1.7 5.5 4.8 4.1z" fill="currentColor" />
    </svg>
  );
}
function ArrowRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path d="M3 7h8m-3-3l3 3-3 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
