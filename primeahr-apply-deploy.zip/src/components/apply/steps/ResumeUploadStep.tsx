"use client";

import { useRef, useState, useCallback } from "react";
import type { ApplicationData, ParsedResume } from "@/lib/apply/application-schema";

interface Props {
  role: {
    slug: string;
    displayName: string;
    requiredDocuments: string[];
  };
  ensureApplication: () => Promise<{ applicationId: string; resumeToken: string }>;
  onUpdateFormData: (patch: Partial<ApplicationData>) => void;
  onContinue: (args: { parsedResume: ParsedResume | null; summary: string }) => void;
  currentFormData: ApplicationData;
}

type UploadState =
  | { kind: "idle" }
  | { kind: "uploading"; filename: string; size: number }
  | { kind: "parsing"; filename: string }
  | { kind: "parsed"; filename: string; parsedResume: ParsedResume; summary: string }
  | { kind: "uploaded_no_parse"; filename: string; reason: string }
  | { kind: "error"; message: string };

const PARSING_CHECKS = [
  "Reading your resume",
  "Extracting work history",
  "Finding education & certifications",
  "Identifying skills & languages",
  "Almost done…",
];

export function ResumeUploadStep({
  role,
  ensureApplication,
  onUpdateFormData,
  onContinue,
}: Props) {
  const [state, setState] = useState<UploadState>({ kind: "idle" });
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    async (file: File) => {
      // Quick client-side validation
      const allowed = ["application/pdf", "image/png", "image/jpeg", "image/webp"];
      if (!allowed.includes(file.type)) {
        setState({
          kind: "error",
          message: "Please upload a PDF, PNG, JPG, or WEBP file.",
        });
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setState({
          kind: "error",
          message: "File is too large (max 10 MB). Try compressing the PDF.",
        });
        return;
      }

      setState({ kind: "uploading", filename: file.name, size: file.size });

      try {
        const { applicationId, resumeToken } = await ensureApplication();

        const form = new FormData();
        form.append("file", file);
        form.append("applicationId", applicationId);
        form.append("resumeToken", resumeToken);

        setState({ kind: "parsing", filename: file.name });

        const res = await fetch("/api/ai/parse-resume", {
          method: "POST",
          body: form,
        });

        const data = await res.json();

        if (!res.ok) {
          setState({
            kind: "error",
            message: data.error ?? "Upload failed. Try again.",
          });
          return;
        }

        if (data.parsed === false) {
          setState({
            kind: "uploaded_no_parse",
            filename: file.name,
            reason: data.error ?? "Couldn't parse this file. You can fill it out manually.",
          });
          return;
        }

        // Pre-fill the form data with parsed info
        if (data.prefill) {
          onUpdateFormData(data.prefill);
        }

        setState({
          kind: "parsed",
          filename: file.name,
          parsedResume: data.parsedResume,
          summary: data.summary ?? "",
        });
      } catch (err) {
        setState({
          kind: "error",
          message: err instanceof Error ? err.message : "Something went wrong.",
        });
      }
    },
    [ensureApplication, onUpdateFormData]
  );

  const onDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setDragging(false);
      const file = e.dataTransfer.files?.[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const onInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const skipResume = useCallback(async () => {
    // Start the application without a resume — just advance
    await ensureApplication();
    onContinue({ parsedResume: null, summary: "" });
  }, [ensureApplication, onContinue]);

  return (
    <>
      <div className="stage-header">
        <div className="stage-eyebrow">Step 1 of 6 · Resume</div>
        <h2 className="stage-title">Let's start with your resume.</h2>
        <p className="stage-sub">
          Upload it once and we'll fill in most of the application for you. You can edit
          everything before submitting. No resume? You can skip and type it in.
        </p>
      </div>

      {state.kind === "idle" && (
        <>
          <input
            ref={inputRef}
            type="file"
            accept=".pdf,application/pdf,image/png,image/jpeg,image/webp"
            onChange={onInputChange}
            style={{ display: "none" }}
            aria-label="Upload resume"
          />
          <div
            className="dropzone"
            data-dragging={dragging}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            onClick={() => inputRef.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                inputRef.current?.click();
              }
            }}
          >
            <div className="dropzone-icon" aria-hidden>
              <UploadCloudIcon />
            </div>
            <h3 className="dropzone-title">Drop your resume here</h3>
            <p className="dropzone-sub">PDF, PNG, or JPG · max 10 MB</p>

            <button
              type="button"
              className="dropzone-button"
              onClick={(e) => {
                e.stopPropagation();
                inputRef.current?.click();
              }}
            >
              <FolderIcon />
              Browse files
            </button>

            <div className="dropzone-or">or</div>

            <button
              type="button"
              className="dropzone-skip"
              onClick={(e) => {
                e.stopPropagation();
                skipResume();
              }}
            >
              Skip — I'll fill it out manually →
            </button>
          </div>

          <PrivacyNote />
        </>
      )}

      {(state.kind === "uploading" || state.kind === "parsing") && (
        <ParsingCard filename={state.filename} stage={state.kind} />
      )}

      {state.kind === "parsed" && (
        <ParsedSuccessCard
          filename={state.filename}
          parsedResume={state.parsedResume}
          summary={state.summary}
          onContinue={() => onContinue({ parsedResume: state.parsedResume, summary: state.summary })}
          onRetry={() => setState({ kind: "idle" })}
        />
      )}

      {state.kind === "uploaded_no_parse" && (
        <NoParseCard
          filename={state.filename}
          reason={state.reason}
          onContinue={() => onContinue({ parsedResume: null, summary: "" })}
          onRetry={() => setState({ kind: "idle" })}
        />
      )}

      {state.kind === "error" && (
        <ErrorCard message={state.message} onRetry={() => setState({ kind: "idle" })} />
      )}
    </>
  );
}

function ParsingCard({ filename, stage }: { filename: string; stage: "uploading" | "parsing" }) {
  return (
    <div className="parsing-card">
      <div className="parsing-aura">
        <SparkleIcon size={32} />
      </div>
      <div className="parsing-text">
        <h3 className="parsing-title">
          {stage === "uploading" ? "Uploading your resume…" : "Reading your resume…"}
        </h3>
        <p className="parsing-sub">
          {filename} · This usually takes 5–10 seconds
        </p>
      </div>

      {stage === "parsing" && (
        <div className="parsing-checklist">
          {PARSING_CHECKS.map((label, i) => (
            <div key={i} className="parsing-check" data-done={i < 3 ? "true" : "false"}>
              <span className="parsing-check-dot">
                {i < 3 && <CheckMarkIcon size={8} />}
              </span>
              {label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ParsedSuccessCard({
  filename,
  parsedResume,
  summary,
  onContinue,
  onRetry,
}: {
  filename: string;
  parsedResume: ParsedResume;
  summary: string;
  onContinue: () => void;
  onRetry: () => void;
}) {
  const signals = parsedResume.aiSignals;
  const workCount = parsedResume.workHistory.length;
  const eduCount = parsedResume.education.length;
  const certCount = parsedResume.certifications.length;
  const skillCount = parsedResume.skills.length;

  return (
    <>
      <div className="ai-summary">
        <div className="ai-summary-eyebrow">
          <SparkleIcon size={12} />
          Resume parsed
        </div>
        {summary ? (
          <p className="ai-summary-text">{summary}</p>
        ) : (
          <p className="ai-summary-text">
            We extracted {workCount} job{workCount === 1 ? "" : "s"}, {eduCount}{" "}
            education entr{eduCount === 1 ? "y" : "ies"}, and {certCount} certification
            {certCount === 1 ? "" : "s"} from your resume.
          </p>
        )}
        <div className="ai-summary-stats">
          {signals.yearsOfRelevantExperience != null && (
            <span className="ai-summary-stat">
              <strong>{signals.yearsOfRelevantExperience} yrs</strong> relevant experience
            </span>
          )}
          {signals.hasBachelorsDegree && (
            <span className="ai-summary-stat">
              <strong>Bachelor's</strong>
              {signals.bachelorsFieldOfStudy ? ` · ${signals.bachelorsFieldOfStudy}` : ""}
            </span>
          )}
          {signals.hasCaseManagementExperience && (
            <span className="ai-summary-stat">
              <strong>Case management</strong> experience
            </span>
          )}
          {signals.hasHCBSWaiverExperience && (
            <span className="ai-summary-stat">
              <strong>HCBS waiver</strong> background
            </span>
          )}
          {signals.hasISPWritingExperience && (
            <span className="ai-summary-stat">
              <strong>ISP writing</strong> experience
            </span>
          )}
          {signals.hasLTSSMarylandExperience && (
            <span className="ai-summary-stat">
              <strong>LTSSMaryland</strong>
            </span>
          )}
          {signals.hasIDDPopulationExperience && (
            <span className="ai-summary-stat">
              <strong>I/DD population</strong>
            </span>
          )}
          {signals.languagesSpoken && signals.languagesSpoken.length > 0 && (
            <span className="ai-summary-stat">
              <strong>{signals.languagesSpoken.join(", ")}</strong>
            </span>
          )}
          {skillCount > 0 && (
            <span className="ai-summary-stat">
              <strong>{skillCount}</strong> skills identified
            </span>
          )}
        </div>
      </div>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "16px 20px",
          background: "var(--apply-paper-soft)",
          border: "1px solid var(--apply-border)",
          borderRadius: "var(--apply-r)",
          marginBottom: 24,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: "var(--apply-r-sm)",
              background: "var(--apply-emerald-tint)",
              color: "var(--apply-emerald-deep)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <FileIcon />
          </div>
          <div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>{filename}</div>
            <div style={{ fontSize: 12.5, color: "var(--apply-ink-faint)" }}>
              Uploaded · parsed successfully
            </div>
          </div>
        </div>
        <button type="button" className="btn btn-ghost" onClick={onRetry}>
          Replace
        </button>
      </div>

      <p
        style={{
          fontSize: 14,
          color: "var(--apply-ink-muted)",
          lineHeight: 1.55,
          marginBottom: 28,
        }}
      >
        We've pre-filled the next steps with what we found. You'll be able to review and
        correct anything before submitting.
      </p>

      <div className="wizard-nav">
        <div />
        <button type="button" className="btn btn-primary" onClick={onContinue}>
          Continue → review what we found
          <ArrowRight />
        </button>
      </div>
    </>
  );
}

function NoParseCard({
  filename,
  reason,
  onContinue,
  onRetry,
}: {
  filename: string;
  reason: string;
  onContinue: () => void;
  onRetry: () => void;
}) {
  return (
    <>
      <div
        style={{
          background: "#FEF8E7",
          border: "1px solid var(--apply-amber)",
          borderRadius: "var(--apply-r-lg)",
          padding: "24px 28px",
          marginBottom: 24,
        }}
      >
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            fontSize: 11.5,
            fontWeight: 700,
            letterSpacing: "0.1em",
            textTransform: "uppercase",
            color: "#8A5F0F",
            marginBottom: 10,
          }}
        >
          Resume uploaded
        </div>
        <p style={{ fontSize: 16, lineHeight: 1.5, color: "var(--apply-ink)", margin: "0 0 6px" }}>
          Your file <strong>{filename}</strong> is saved, but we couldn't auto-fill from
          it.
        </p>
        <p style={{ fontSize: 14, color: "var(--apply-ink-muted)", margin: 0 }}>
          {reason} No worries — you can fill the next steps manually.
        </p>
      </div>

      <div className="wizard-nav">
        <button type="button" className="btn btn-ghost" onClick={onRetry}>
          Try a different file
        </button>
        <button type="button" className="btn btn-primary" onClick={onContinue}>
          Continue manually
          <ArrowRight />
        </button>
      </div>
    </>
  );
}

function ErrorCard({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div
      style={{
        background: "#FDF1F0",
        border: "1px solid var(--apply-rose)",
        borderRadius: "var(--apply-r-lg)",
        padding: "24px 28px",
      }}
    >
      <h3
        style={{
          fontFamily: "var(--apply-font-display)",
          fontSize: 20,
          fontWeight: 500,
          color: "var(--apply-ink)",
          margin: "0 0 8px",
        }}
      >
        Something went wrong
      </h3>
      <p style={{ fontSize: 14, color: "var(--apply-ink-muted)", margin: "0 0 20px" }}>
        {message}
      </p>
      <button type="button" className="btn btn-primary" onClick={onRetry}>
        Try again
      </button>
    </div>
  );
}

function PrivacyNote() {
  return (
    <p
      style={{
        fontSize: 12.5,
        color: "var(--apply-ink-faint)",
        textAlign: "center",
        marginTop: 24,
        lineHeight: 1.6,
      }}
    >
      🔒 Your resume is encrypted in transit and at rest. We only use it for this
      application. Read our{" "}
      <a href="/privacy" style={{ color: "var(--apply-ink-muted)", textDecoration: "underline" }}>
        privacy policy
      </a>
      .
    </p>
  );
}

// ============================================================================
// Icons
// ============================================================================
function UploadCloudIcon() {
  return (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden>
      <path
        d="M22 20c2.5 0 4.5-2 4.5-4.5S24.5 11 22 11c-.2 0-.4 0-.6.05C20.7 7.6 17.6 5 14 5c-4.4 0-8 3.6-8 8 0 .3 0 .6.05.9C3.8 14.5 2 16.6 2 19c0 2.8 2.2 5 5 5h4"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16 19v9m-4-5l4-4 4 4"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function FolderIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden>
      <path
        d="M2 5a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function SparkleIcon({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none" aria-hidden>
      <path
        d="M7 1.5l1.4 3.6L12 6.5 9 8.7l1 3.8L7 10.5 4 12.5l1-3.8L2 6.5l3.6-1.4z"
        fill="currentColor"
      />
    </svg>
  );
}

function FileIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden>
      <path
        d="M5 2h6l4 4v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path d="M11 2v4h4" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}

function CheckMarkIcon({ size = 10 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 10 10" fill="none" aria-hidden>
      <path
        d="M2 5l2 2 4-4.5"
        stroke="white"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ArrowRight() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path
        d="M3 7h8m-3-3l3 3-3 3"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
