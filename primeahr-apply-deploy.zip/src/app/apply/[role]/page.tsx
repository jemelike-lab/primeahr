import { notFound } from "next/navigation";
import { createAnonClient } from "@/lib/apply/supabase";
import { ApplicationWizard } from "@/components/apply/ApplicationWizard";
import type { Metadata } from "next";
import "@/styles/apply.css";

interface PageProps {
  params: Promise<{ role: string }>;
  searchParams: Promise<{ req?: string; ref?: string; resume?: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { role } = await params;
  const supabase = createAnonClient();
  const { data } = await supabase
    .from("role_templates")
    .select("display_name, short_description")
    .eq("slug", role)
    .eq("active", true)
    .eq("is_public", true)
    .maybeSingle();

  if (!data) {
    return { title: "Apply — Beatrice Loving Heart" };
  }

  return {
    title: `Apply: ${data.display_name} — Beatrice Loving Heart`,
    description: data.short_description ?? undefined,
  };
}

export default async function ApplyPage({ params, searchParams }: PageProps) {
  const { role } = await params;
  const search = await searchParams;
  const supabase = createAnonClient();

  // Load the role template
  const { data: roleData, error } = await supabase
    .from("role_templates")
    .select("*")
    .eq("slug", role)
    .eq("active", true)
    .eq("is_public", true)
    .maybeSingle();

  if (error || !roleData) {
    notFound();
  }

  // If there's a `?resume=<token>` query, load that application for save-and-resume
  let resumedApplication = null;
  if (search.resume) {
    const { data } = await supabase
      .from("applications")
      .select("id, resume_token, current_step, form_data, status")
      .eq("resume_token", search.resume)
      .maybeSingle();

    if (data && data.status === "in_progress") {
      resumedApplication = data;
    }
  }

  return (
    <main className="apply-shell">
      <BackgroundDecor />

      <header className="apply-header">
        <a href="/" className="apply-brand">
          <BrandMark />
          <span className="apply-brand-text">
            <span className="apply-brand-name">Beatrice Loving Heart</span>
            <span className="apply-brand-tag">Maryland · Home & Community</span>
          </span>
        </a>
        <a href="mailto:careers@beatricelovingheart.com" className="apply-contact-link">
          Need help?
        </a>
      </header>

      <section className="apply-hero">
        <div className="apply-hero-eyebrow">
          <span className="apply-hero-dot" /> Now hiring · Maryland
        </div>
        <h1 className="apply-hero-title">
          <span className="apply-hero-pre">Apply for</span>
          <span className="apply-hero-role">{roleData.display_name}</span>
        </h1>
        {roleData.short_description && (
          <p className="apply-hero-sub">{roleData.short_description}</p>
        )}

        {(roleData.pay_range_min || roleData.pay_range_max) && (
          <div className="apply-hero-meta">
            <MetaPill icon="dollar">
              {formatPay(
                roleData.pay_range_min,
                roleData.pay_range_max,
                roleData.pay_frequency ?? "hourly"
              )}
            </MetaPill>
            <MetaPill icon="clock">~ 12 minutes to apply</MetaPill>
            <MetaPill icon="sparkle">Resume? We fill it in for you</MetaPill>
          </div>
        )}
      </section>

      <ApplicationWizard
        role={{
          slug: roleData.slug,
          displayName: roleData.display_name,
          longDescription: roleData.long_description,
          responsibilities: (roleData.responsibilities as string[]) ?? [],
          requirements: (roleData.requirements as string[]) ?? [],
          niceToHaves: (roleData.nice_to_haves as string[]) ?? [],
          requiredDocuments: (roleData.required_documents as string[]) ?? [],
          optionalDocuments: (roleData.optional_documents as string[]) ?? [],
        }}
        requisitionId={search.req ?? null}
        referralSource={search.ref ?? null}
        resumedApplication={
          resumedApplication
            ? {
                applicationId: resumedApplication.id,
                resumeToken: resumedApplication.resume_token!,
                currentStep: resumedApplication.current_step,
                formData: resumedApplication.form_data,
              }
            : null
        }
      />

      <footer className="apply-footer">
        <div className="apply-footer-inner">
          <span>© {new Date().getFullYear()} Beatrice Loving Heart</span>
          <div className="apply-footer-links">
            <a href="/privacy">Privacy</a>
            <a href="/terms">Terms</a>
            <a href="/accessibility">Accessibility</a>
          </div>
        </div>
      </footer>
    </main>
  );
}

function BackgroundDecor() {
  return (
    <div className="apply-bg" aria-hidden>
      <div className="apply-bg-orb apply-bg-orb-1" />
      <div className="apply-bg-orb apply-bg-orb-2" />
      <div className="apply-bg-grid" />
    </div>
  );
}

function BrandMark() {
  return (
    <svg className="apply-brand-mark" width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden>
      <defs>
        <linearGradient id="bm-grad" x1="0" y1="0" x2="40" y2="40">
          <stop offset="0%" stopColor="#0E7C66" />
          <stop offset="100%" stopColor="#1F9E80" />
        </linearGradient>
      </defs>
      <path
        d="M20 6.5c-3-3.2-9-3-11.5.5-2.5 3.5-1.5 8 1.5 11l9 9.5c.6.6 1.6.6 2.2 0l9-9.5c3-3 4-7.5 1.5-11s-8.5-3.7-11.5-.5z"
        fill="url(#bm-grad)"
      />
      <path
        d="M14 19c1.5 0 2.5 1 3 2.5"
        stroke="#FAF7F2"
        strokeWidth="1.6"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

function MetaPill({ icon, children }: { icon: "dollar" | "clock" | "sparkle"; children: React.ReactNode }) {
  return (
    <span className="apply-meta-pill">
      <PillIcon icon={icon} />
      {children}
    </span>
  );
}

function PillIcon({ icon }: { icon: "dollar" | "clock" | "sparkle" }) {
  if (icon === "dollar") {
    return (
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
        <path d="M7 1v12M9.5 4H5.75a1.75 1.75 0 1 0 0 3.5h2.5a1.75 1.75 0 1 1 0 3.5H4.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
    );
  }
  if (icon === "clock") {
    return (
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
        <circle cx="7" cy="7" r="5.5" stroke="currentColor" strokeWidth="1.4" />
        <path d="M7 4v3l2 1.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path d="M7 1.5l1.4 3.6L12 6.5 9 8.7l1 3.8L7 10.5 4 12.5l1-3.8L2 6.5l3.6-1.4z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
    </svg>
  );
}

function formatPay(min: number | null, max: number | null, freq: string): string {
  if (!min && !max) return "Competitive pay";
  const fmt = (n: number) =>
    freq === "hourly"
      ? `$${n.toFixed(2)}/hr`
      : `$${(n / 1000).toFixed(0)}k`;
  if (min && max) return `${fmt(min)} – ${fmt(max)}`;
  return fmt((min ?? max)!);
}
