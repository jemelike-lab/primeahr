import { NextRequest, NextResponse } from "next/server";
import { createServiceClient, buildApplicationStoragePath, APPLICATION_BUCKET } from "@/lib/apply/supabase";
import { parseResume, generateCandidateSummary } from "@/lib/apply/resume-parser";

/**
 * POST /api/ai/parse-resume
 *
 * Multipart form upload:
 *   - file: PDF or image of the resume
 *   - applicationId: UUID
 *   - resumeToken: magic token
 *
 * Flow:
 *   1. Verify the application + token
 *   2. Upload the file to Supabase Storage
 *   3. Run Claude resume parser
 *   4. Generate AI summary
 *   5. Update application with parsed data
 *   6. Pre-fill personal info, work history, education, certifications, skills
 *   7. Return parsed data + filled form_data
 */
export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();

    const file = form.get("file");
    const applicationId = form.get("applicationId");
    const resumeToken = form.get("resumeToken");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "file is required" }, { status: 400 });
    }
    if (typeof applicationId !== "string" || typeof resumeToken !== "string") {
      return NextResponse.json(
        { error: "applicationId and resumeToken are required" },
        { status: 400 }
      );
    }

    // Hard size limit — 10MB
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        { error: "Resume file is too large (max 10MB)" },
        { status: 413 }
      );
    }

    const allowedTypes = [
      "application/pdf",
      "image/png",
      "image/jpeg",
      "image/webp",
    ];
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: `Unsupported file type: ${file.type}. Use PDF, PNG, JPG, or WEBP.` },
        { status: 415 }
      );
    }

    const supabase = createServiceClient();

    // Verify the application
    const { data: app, error: lookupErr } = await supabase
      .from("applications")
      .select("id, resume_token, status, form_data, role_slug")
      .eq("id", applicationId)
      .maybeSingle();

    if (lookupErr || !app) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }
    if (app.resume_token !== resumeToken) {
      return NextResponse.json({ error: "Invalid resume token" }, { status: 403 });
    }
    if (app.status !== "in_progress") {
      return NextResponse.json(
        { error: `Application is already ${app.status}` },
        { status: 409 }
      );
    }

    // Read the file into memory
    const fileBuffer = Buffer.from(await file.arrayBuffer());

    // Upload to storage
    const storagePath = buildApplicationStoragePath(
      applicationId,
      "resume",
      file.name
    );

    const { error: uploadErr } = await supabase.storage
      .from(APPLICATION_BUCKET)
      .upload(storagePath, fileBuffer, {
        contentType: file.type,
        upsert: false,
      });

    if (uploadErr) {
      return NextResponse.json(
        { error: `Storage upload failed: ${uploadErr.message}` },
        { status: 500 }
      );
    }

    // Run Claude resume parser
    let parsedResult;
    try {
      parsedResult = await parseResume({
        fileBuffer,
        mediaType: file.type as "application/pdf" | "image/png" | "image/jpeg" | "image/webp",
      });
    } catch (parseErr) {
      // Parsing failed but the file uploaded — let the candidate continue manually
      console.error("[/api/ai/parse-resume] parse failed:", parseErr);

      await supabase.from("applications").update({
        resume_storage_path: storagePath,
        resume_filename: file.name,
      }).eq("id", applicationId);

      await supabase.from("application_events").insert({
        application_id: applicationId,
        event_type: "resume_uploaded",
        actor: "candidate",
        metadata: { storagePath, parseFailed: true, error: String(parseErr) },
      });

      return NextResponse.json({
        parsed: false,
        storagePath,
        error: "Resume uploaded but couldn't be parsed automatically. You can continue filling out the form manually.",
      }, { status: 200 });
    }

    // Generate AI summary (don't fail the request if this errors)
    let summary = "";
    try {
      summary = await generateCandidateSummary(parsedResult.parsed);
    } catch (sumErr) {
      console.error("[/api/ai/parse-resume] summary failed:", sumErr);
    }

    // Build form_data pre-fill from parsed resume
    const parsed = parsedResult.parsed;
    const prefill = {
      personal: {
        firstName: parsed.personal.firstName ?? undefined,
        middleName: parsed.personal.middleName ?? undefined,
        lastName: parsed.personal.lastName ?? undefined,
        email: parsed.personal.email ?? undefined,
        phone: parsed.personal.phone ?? undefined,
        address: parsed.personal.address
          ? {
              line1: parsed.personal.address.line1 ?? "",
              line2: parsed.personal.address.line2 ?? "",
              city: parsed.personal.address.city ?? "",
              state: parsed.personal.address.state ?? "",
              zip: parsed.personal.address.zip ?? "",
            }
          : undefined,
      },
      workHistory: {
        entries: parsed.workHistory.map((w) => ({
          employer: w.employer ?? "",
          jobTitle: w.jobTitle ?? "",
          city: w.city ?? "",
          state: w.state ?? "",
          startDate: w.startDate ?? "",
          endDate: w.endDate ?? "",
          isCurrent: w.isCurrent,
          responsibilities: w.responsibilities ?? "",
        })),
      },
      education: {
        entries: parsed.education.map((e) => ({
          institutionName: e.institutionName ?? "",
          degree: e.degree ?? "",
          fieldOfStudy: e.fieldOfStudy ?? "",
          city: e.city ?? "",
          state: e.state ?? "",
          graduationDate: e.graduationDate ?? "",
          isCompleted: e.isCompleted,
        })),
        highestLevelCompleted: inferEducationLevel(parsed.education),
      },
      certifications: {
        entries: parsed.certifications.map((c) => ({
          name: c.name ?? "",
          issuingOrganization: c.issuingOrganization ?? "",
          licenseNumber: c.licenseNumber ?? "",
          issuedDate: c.issuedDate ?? "",
          expirationDate: c.expirationDate ?? "",
          state: c.state ?? "",
          isActive: true,
        })),
        hasNoCertifications: parsed.certifications.length === 0,
      },
    };

    const mergedFormData = {
      ...(app.form_data as Record<string, unknown> ?? {}),
      ...prefill,
    };

    // Update the application
    await supabase
      .from("applications")
      .update({
        resume_storage_path: storagePath,
        resume_filename: file.name,
        resume_parsed: parsedResult.parsed,
        form_data: mergedFormData,
        ai_summary: summary || null,
      })
      .eq("id", applicationId);

    // Log events
    await supabase.from("application_events").insert([
      {
        application_id: applicationId,
        event_type: "resume_uploaded",
        actor: "candidate",
        metadata: { storagePath, filename: file.name, size: file.size },
      },
      {
        application_id: applicationId,
        event_type: "resume_parsed",
        actor: "ai",
        metadata: {
          model: parsedResult.modelUsed,
          tokens: parsedResult.usage,
          signals: parsed.aiSignals,
        },
      },
    ]);

    return NextResponse.json({
      parsed: true,
      storagePath,
      parsedResume: parsed,
      summary,
      prefill,
    });
  } catch (err) {
    console.error("[/api/ai/parse-resume] error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}

function inferEducationLevel(
  education: Array<{ degree: string | null; isCompleted: boolean }>
): string {
  const degrees = education
    .filter((e) => e.isCompleted)
    .map((e) => e.degree?.toLowerCase() ?? "");

  if (degrees.some((d) => d.includes("phd") || d.includes("doctor"))) return "doctorate";
  if (degrees.some((d) => d.includes("master") || d.includes("mba") || d.includes("msn"))) return "masters";
  if (degrees.some((d) => d.includes("bachelor") || d.includes("bs ") || d.includes("ba "))) return "bachelors";
  if (degrees.some((d) => d.includes("associate") || d.includes("aa ") || d.includes("as "))) return "associates";
  if (degrees.some((d) => d.includes("ged"))) return "ged";
  if (degrees.some((d) => d.includes("high school") || d.includes("hs diploma"))) return "high_school";
  return "other";
}
