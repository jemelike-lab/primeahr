import { NextRequest, NextResponse } from "next/server";
import { createServiceClient } from "@/lib/apply/supabase";
import { applicationDataSchema } from "@/lib/apply/application-schema";

/**
 * POST /api/apply/save
 *
 * Auto-save the application form data. Called every few seconds from
 * the wizard. Validates against the partial schema and merges into form_data.
 *
 * Body:
 *   { applicationId, resumeToken, currentStep, formData }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { applicationId, resumeToken, currentStep, formData } = body as {
      applicationId?: string;
      resumeToken?: string;
      currentStep?: number;
      formData?: unknown;
    };

    if (!applicationId || !resumeToken) {
      return NextResponse.json(
        { error: "applicationId and resumeToken are required" },
        { status: 400 }
      );
    }

    const supabase = createServiceClient();

    // Verify token matches application
    const { data: app, error: lookupErr } = await supabase
      .from("applications")
      .select("id, resume_token, resume_token_expires_at, status, form_data")
      .eq("id", applicationId)
      .maybeSingle();

    if (lookupErr || !app) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }
    if (app.resume_token !== resumeToken) {
      return NextResponse.json({ error: "Invalid resume token" }, { status: 403 });
    }
    if (app.resume_token_expires_at && new Date(app.resume_token_expires_at) < new Date()) {
      return NextResponse.json({ error: "Resume token has expired" }, { status: 410 });
    }
    if (app.status !== "in_progress") {
      return NextResponse.json(
        { error: `Application is already ${app.status}` },
        { status: 409 }
      );
    }

    // Validate the form data (partial OK — we're saving as they go)
    const validated = applicationDataSchema.partial().safeParse(formData ?? {});
    if (!validated.success) {
      return NextResponse.json(
        { error: "Invalid form data", details: validated.error.flatten() },
        { status: 400 }
      );
    }

    // Merge into existing form_data
    const mergedFormData = {
      ...(app.form_data as Record<string, unknown> ?? {}),
      ...validated.data,
    };

    const update: Record<string, unknown> = {
      form_data: mergedFormData,
    };
    if (typeof currentStep === "number" && currentStep >= 1 && currentStep <= 8) {
      update.current_step = currentStep;
    }

    const { error: updateErr } = await supabase
      .from("applications")
      .update(update)
      .eq("id", applicationId);

    if (updateErr) {
      return NextResponse.json({ error: updateErr.message }, { status: 500 });
    }

    return NextResponse.json({ saved: true, currentStep });
  } catch (err) {
    console.error("[/api/apply/save] error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}
