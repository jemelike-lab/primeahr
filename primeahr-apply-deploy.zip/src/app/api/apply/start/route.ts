import { NextRequest, NextResponse } from "next/server";
import { createServiceClient, generateResumeToken } from "@/lib/apply/supabase";

/**
 * POST /api/apply/start
 *
 * Creates a new application record and returns:
 *   - applicationId: UUID
 *   - resumeToken: magic token for save-and-resume
 *
 * The candidate's full identity isn't known yet. We create the shell record
 * and let the wizard fill it in step by step.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { roleSlug, requisitionId, referralSource } = body as {
      roleSlug?: string;
      requisitionId?: string | null;
      referralSource?: string;
    };

    if (!roleSlug || typeof roleSlug !== "string") {
      return NextResponse.json(
        { error: "roleSlug is required" },
        { status: 400 }
      );
    }

    const supabase = createServiceClient();

    // Validate the role exists and is active
    const { data: role, error: roleErr } = await supabase
      .from("role_templates")
      .select("id, slug, active, is_public, display_name")
      .eq("slug", roleSlug)
      .eq("active", true)
      .eq("is_public", true)
      .maybeSingle();

    if (roleErr) {
      return NextResponse.json({ error: roleErr.message }, { status: 500 });
    }
    if (!role) {
      return NextResponse.json(
        { error: `Role "${roleSlug}" not found or not currently accepting applications` },
        { status: 404 }
      );
    }

    // Generate the magic token for save-and-resume
    const resumeToken = generateResumeToken();
    const tokenExpires = new Date();
    tokenExpires.setDate(tokenExpires.getDate() + 30); // 30 days to finish

    const { data: application, error: appErr } = await supabase
      .from("applications")
      .insert({
        role_slug: roleSlug,
        requisition_id: requisitionId ?? null,
        status: "in_progress",
        current_step: 1,
        total_steps: 8,
        resume_token: resumeToken,
        resume_token_expires_at: tokenExpires.toISOString(),
        form_data: {
          personal: referralSource ? { referralSource } : undefined,
        },
      })
      .select("id, resume_token, current_step")
      .single();

    if (appErr || !application) {
      return NextResponse.json(
        { error: appErr?.message ?? "Failed to create application" },
        { status: 500 }
      );
    }

    // Log the event
    await supabase.from("application_events").insert({
      application_id: application.id,
      event_type: "created",
      actor: "candidate",
      metadata: {
        roleSlug,
        requisitionId: requisitionId ?? null,
        referralSource: referralSource ?? null,
        userAgent: req.headers.get("user-agent") ?? null,
      },
    });

    return NextResponse.json({
      applicationId: application.id,
      resumeToken: application.resume_token,
      currentStep: application.current_step,
      role: {
        slug: role.slug,
        displayName: role.display_name,
      },
    });
  } catch (err) {
    console.error("[/api/apply/start] error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}
