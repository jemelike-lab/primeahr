import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { createServiceClient } from "@/lib/apply/supabase";

/**
 * POST /api/apply/score
 *
 * Score a candidate against a requisition using Claude.
 * Called async by /api/apply/submit, or manually by recruiters.
 *
 * Body: { applicationId, requisitionId, candidateId }
 *
 * Returns: { fit_score, reasoning, strengths, gaps, recommended_action }
 */

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const MODEL = "claude-sonnet-4-20250514";

const SCORING_TOOL = {
  name: "submit_candidate_score",
  description: "Submit the fit score and analysis for this candidate.",
  input_schema: {
    type: "object",
    required: ["fit_score", "reasoning", "strengths", "gaps", "recommended_action"],
    properties: {
      fit_score: {
        type: "integer",
        minimum: 0,
        maximum: 100,
        description: "Overall fit score from 0-100. Be honest. Reserve 90+ for strong matches, 70-89 for solid candidates, 50-69 for possible fits with gaps, 30-49 for stretch candidates, below 30 for poor fit.",
      },
      reasoning: {
        type: "string",
        description: "2-3 sentence summary of the score. Specific and factual.",
      },
      strengths: {
        type: "array",
        items: { type: "string" },
        description: "Concrete strengths matching the requisition (3-5 bullets).",
      },
      gaps: {
        type: "array",
        items: { type: "string" },
        description: "Concrete gaps or missing requirements (0-5 bullets).",
      },
      recommended_action: {
        type: "string",
        enum: ["fast_track", "standard_review", "screen_first", "pass"],
        description: "fast_track for top candidates ready to interview. standard_review for solid candidates. screen_first for promising but uncertain. pass for poor fits.",
      },
    },
  },
} as const;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { applicationId, requisitionId, candidateId } = body as {
      applicationId?: string;
      requisitionId?: string;
      candidateId?: string;
    };

    if (!applicationId || !requisitionId || !candidateId) {
      return NextResponse.json(
        { error: "applicationId, requisitionId, and candidateId are required" },
        { status: 400 }
      );
    }

    const supabase = createServiceClient();

    // Fetch application + requisition in parallel
    const [appRes, reqRes] = await Promise.all([
      supabase
        .from("applications")
        .select("id, resume_parsed, form_data, ai_summary, role_slug")
        .eq("id", applicationId)
        .maybeSingle(),
      supabase
        .from("requisitions")
        .select("*")
        .eq("id", requisitionId)
        .maybeSingle(),
    ]);

    if (appRes.error || !appRes.data) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }
    if (reqRes.error || !reqRes.data) {
      return NextResponse.json({ error: "Requisition not found" }, { status: 404 });
    }

    const application = appRes.data;
    const requisition = reqRes.data;

    // Build the scoring prompt
    const systemPrompt = `You are an expert recruiter at Beatrice Loving Heart (BLH), a Maryland case management and care coordination agency. BLH serves participants in the Community First Choice (CFC) program and Developmental Disabilities Administration (DDA) HCBS waivers. BLH does NOT provide direct care — our staff coordinate services, write Person-Centered Plans / ISPs, monitor service delivery, and document in LTSSMaryland.

You score candidate fit against open requisitions.

Scoring philosophy:
- Be honest and specific. Don't inflate scores. A 75 is a strong candidate. A 90+ is exceptional. Reserve 90+ for candidates who clearly exceed the role requirements.
- For Support Planner and Coordinator of Community Services (CCS) roles, weight HEAVILY:
  · Bachelor's degree (required for CCS per COMAR 10.22; strongly preferred for SP)
  · Field of study (Social Work, Psychology, Human Services, Sociology, Education are most relevant)
  · Prior case management, service coordination, or care coordination experience
  · HCBS waiver familiarity (CFC, DDA, ECSP, CDS, or other 1915(c) waivers)
  · I/DD population experience for CCS roles specifically
  · ISP / Person-Centered Plan writing experience
  · LTSSMaryland system experience (huge plus — short learning curve)
  · Writing and documentation quality (inferred from resume itself)
  · Bilingual ability (Spanish especially — high candidate population in MD)
- For Administrative, HR, Onboarding, and Specialist roles, weight what's relevant to that specific role description. Do not penalize an Admin Assistant candidate for lacking case management experience.
- Job stability matters. Frequent job changes (5+ jobs in 3 years) is a concern but not disqualifying — explain context if relevant.
- Maryland location / county coverage is relevant for SP and CCS (field visits required).
- A clinical background is NOT a plus or a minus for BLH roles unless the requisition specifically calls for it (none of our standard roles do).
- Always provide concrete strengths and gaps — never generic statements like "good communication skills" without evidence.

Call the submit_candidate_score tool with your analysis. Never respond with plain text.`;

    const userMessage = `Score this candidate against the requisition:

==== REQUISITION ====
${JSON.stringify(requisition, null, 2)}

==== CANDIDATE RESUME (PARSED) ====
${JSON.stringify(application.resume_parsed ?? {}, null, 2)}

==== CANDIDATE APPLICATION DATA ====
${JSON.stringify(application.form_data ?? {}, null, 2)}

==== AI SUMMARY ====
${application.ai_summary ?? "(not available)"}

Score this candidate and call submit_candidate_score.`;

    const response = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 1500,
      system: systemPrompt,
      tools: [SCORING_TOOL as unknown as Anthropic.Messages.Tool],
      tool_choice: { type: "tool", name: "submit_candidate_score" },
      messages: [{ role: "user", content: userMessage }],
    });

    const toolBlock = response.content.find(
      (b): b is Anthropic.Messages.ToolUseBlock => b.type === "tool_use"
    );

    if (!toolBlock) {
      return NextResponse.json(
        { error: "Claude did not return a score" },
        { status: 502 }
      );
    }

    const score = toolBlock.input as {
      fit_score: number;
      reasoning: string;
      strengths: string[];
      gaps: string[];
      recommended_action: string;
    };

    // Persist the score
    await supabase.from("candidate_scores").upsert(
      {
        candidate_id: candidateId,
        requisition_id: requisitionId,
        fit_score: score.fit_score,
        reasoning: score.reasoning,
        strengths: score.strengths,
        gaps: score.gaps,
        recommended_action: score.recommended_action,
        model: MODEL,
        prompt_version: "v1",
        scored_at: new Date().toISOString(),
      },
      { onConflict: "candidate_id,requisition_id" }
    );

    // Also denormalize onto the application for easy reads
    await supabase
      .from("applications")
      .update({
        ai_fit_score: score.fit_score,
        ai_fit_reasoning: score.reasoning,
        ai_strengths: score.strengths,
        ai_gaps: score.gaps,
        ai_scored_at: new Date().toISOString(),
      })
      .eq("id", applicationId);

    await supabase.from("application_events").insert({
      application_id: applicationId,
      event_type: "ai_scored",
      actor: "ai",
      metadata: {
        fit_score: score.fit_score,
        recommended_action: score.recommended_action,
        requisition_id: requisitionId,
        usage: {
          inputTokens: response.usage.input_tokens,
          outputTokens: response.usage.output_tokens,
        },
      },
    });

    return NextResponse.json(score);
  } catch (err) {
    console.error("[/api/apply/score] error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}
