import { NextRequest, NextResponse } from "next/server";
import {
  createServiceClient,
  buildApplicationStoragePath,
  APPLICATION_BUCKET,
} from "@/lib/apply/supabase";

/**
 * POST /api/apply/upload-document
 *
 * Multipart upload:
 *   - file: any file
 *   - applicationId
 *   - resumeToken
 *   - docType: 'drivers_license' | 'ssn_card' | etc.
 *
 * Stores the file in Supabase Storage and creates an application_documents row.
 * Does NOT run OCR by default — that can be added in Phase E (Mindee).
 */
export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    const applicationId = form.get("applicationId");
    const resumeToken = form.get("resumeToken");
    const docType = form.get("docType");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "file is required" }, { status: 400 });
    }
    if (typeof applicationId !== "string" || typeof resumeToken !== "string" || typeof docType !== "string") {
      return NextResponse.json(
        { error: "applicationId, resumeToken, and docType are required" },
        { status: 400 }
      );
    }

    // Size limit — 15MB (documents may be photos, allow more than resume)
    if (file.size > 15 * 1024 * 1024) {
      return NextResponse.json({ error: "File too large (max 15MB)" }, { status: 413 });
    }

    const supabase = createServiceClient();

    // Verify the application + token
    const { data: app } = await supabase
      .from("applications")
      .select("id, resume_token, status")
      .eq("id", applicationId)
      .maybeSingle();

    if (!app) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }
    if (app.resume_token !== resumeToken) {
      return NextResponse.json({ error: "Invalid resume token" }, { status: 403 });
    }
    if (app.status !== "in_progress") {
      return NextResponse.json(
        { error: `Application is already ${app.status}` },
        { status: 409 }
      );
    }

    const fileBuffer = Buffer.from(await file.arrayBuffer());

    const storagePath = buildApplicationStoragePath(applicationId, docType, file.name);

    const { error: uploadErr } = await supabase.storage
      .from(APPLICATION_BUCKET)
      .upload(storagePath, fileBuffer, {
        contentType: file.type,
        upsert: false,
      });

    if (uploadErr) {
      return NextResponse.json(
        { error: `Upload failed: ${uploadErr.message}` },
        { status: 500 }
      );
    }

    // Insert document record. If the same docType was uploaded before, mark old as superseded.
    await supabase
      .from("application_documents")
      .delete()
      .eq("application_id", applicationId)
      .eq("doc_type", docType);

    const { data: doc, error: docErr } = await supabase
      .from("application_documents")
      .insert({
        application_id: applicationId,
        doc_type: docType,
        storage_path: storagePath,
        file_name: file.name,
        file_size_bytes: file.size,
        mime_type: file.type,
        ocr_status: "pending",
      })
      .select("id")
      .single();

    if (docErr) {
      return NextResponse.json({ error: docErr.message }, { status: 500 });
    }

    await supabase.from("application_events").insert({
      application_id: applicationId,
      event_type: "document_uploaded",
      actor: "candidate",
      metadata: { docType, filename: file.name, size: file.size, documentId: doc.id },
    });

    return NextResponse.json({
      documentId: doc.id,
      storagePath,
      docType,
    });
  } catch (err) {
    console.error("[/api/apply/upload-document] error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}
