import { NextRequest, NextResponse } from "next/server";
import { createServiceClient } from "@/lib/apply/supabase";
import {
  applicationDataSchema,
  signSubmitSchema,
} from "@/lib/apply/application-schema";

/**
 * POST /api/apply/submit
 *
 * Final submission of the application.
 *   1. Validates the COMPLETE form data
 *   2. Captures signature
 *   3. Creates or links a candidate record
 *   4. Flips status to 'submitted'
 *   5. Triggers async AI scoring (not awaited)
 *   6. Returns confirmation page data
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { applicationId, resumeToken, formData, signature } = body as {
      applicationId?: string;
      resumeToken?: string;
      formData?: unknown;
      signature?: unknown;
    };

    if (!applicationId || !resumeToken) {
      return NextResponse.json(
        { error: "applicationId and resumeToken are required" },
        { status: 400 }
      );
    }

    const supabase = createServiceClient();

    const { data: app, error: lookupErr } = await supabase
      .from("applications")
      .select("*")
      .eq("id", applicationId)
      .maybeSingle();

    if (lookupErr || !app) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }
    if (app.resume_token !== resumeToken) {
      return NextResponse.json({ error: "Invalid resume token" }, { status: 403 });
    }
    if (app.status !== "in_progress") {
      return NextResponse.json(
        { error: `Application is already ${app.status}` },
        { status: 409 }
      );
    }

    // Final validation
    const dataValidation = applicationDataSchema.safeParse(formData);
    if (!dataValidation.success) {
      return NextResponse.json(
        { error: "Form data validation failed", details: dataValidation.error.flatten() },
        { status: 400 }
      );
    }

    const sigValidation = signSubmitSchema.safeParse(signature);
    if (!sigValidation.success) {
      return NextResponse.json(
        { error: "Signature validation failed", details: sigValidation.error.flatten() },
        { status: 400 }
      );
    }

    const validatedData = dataValidation.data;
    const sig = sigValidation.data;
    const personal = validatedData.personal;

    if (!personal?.firstName || !personal?.lastName || !personal?.email) {
      return NextResponse.json(
        { error: "First name, last name, and email are required to submit" },
        { status: 400 }
      );
    }

    // Find or create candidate
    let candidateId = app.candidate_id;

    if (!candidateId) {
      // Try to match an existing candidate by email
      const { data: existing } = await supabase
        .from("candidates")
        .select("id")
        .ilike("email", personal.email)
        .maybeSingle();

      if (existing) {
        candidateId = existing.id;
      } else {
        const { data: newCandidate, error: candidateErr } = await supabase
          .from("candidates")
          .insert({
            first_name: personal.firstName,
            last_name: personal.lastName,
            email: personal.email.toLowerCase(),
            phone: personal.phone ?? null,
            city: personal.address?.city ?? null,
            state: personal.address?.state ?? null,
            zip_code: personal.address?.zip ?? null,
            source: personal.referralSource ?? "apply_page",
            source_detail: personal.referrerName ?? null,
            // Full application data goes in JSONB
            application_data: {
              addressLine1: personal.address?.line1 ?? null,
              addressLine2: personal.address?.line2 ?? null,
              preferredName: personal.preferredName ?? null,
              middleName: personal.middleName ?? null,
              authorizedToWorkInUS: personal.authorizedToWorkInUS,
              requiresSponsorship: personal.requiresSponsorship,
            },
            // Work history goes into the JSONB experience column
            experience: validatedData.workHistory?.entries ?? [],
            education: validatedData.education?.entries ?? [],
            // EEO disclosures
            voluntary_self_id: validatedData.background?.voluntaryEEO ?? null,
            criminal_history_disclosed: validatedData.background?.hasBeenConvictedOfCrime ?? null,
            legal_signature_date: new Date().toISOString(),
          })
          .select("id")
          .single();

        if (candidateErr || !newCandidate) {
          return NextResponse.json(
            { error: `Failed to create candidate: ${candidateErr?.message}` },
            { status: 500 }
          );
        }
        candidateId = newCandidate.id;
      }
    }

    // Capture client IP and user-agent for the signature record
    const forwardedFor = req.headers.get("x-forwarded-for");
    const signedIp = forwardedFor?.split(",")[0]?.trim() ?? req.headers.get("x-real-ip") ?? null;
    const signedUserAgent = req.headers.get("user-agent") ?? null;

    // Flip to submitted
    const { error: submitErr } = await supabase
      .from("applications")
      .update({
        candidate_id: candidateId,
        status: "submitted",
        form_data: validatedData,
        signature_data: sig.signatureData,
        signed_at: new Date().toISOString(),
        signed_ip: signedIp,
        signed_user_agent: signedUserAgent,
        submitted_at: new Date().toISOString(),
        current_step: 8,
      })
      .eq("id", applicationId);

    if (submitErr) {
      return NextResponse.json({ error: submitErr.message }, { status: 500 });
    }

    // Audit events
    await supabase.from("application_events").insert([
      {
        application_id: applicationId,
        event_type: "signed",
        actor: "candidate",
        metadata: { fullLegalName: sig.fullLegalName, ip: signedIp },
      },
      {
        application_id: applicationId,
        event_type: "submitted",
        actor: "candidate",
        metadata: { candidateId },
      },
    ]);

    // Fire-and-forget: trigger AI scoring against the requisition (if any).
    // We don't await this — the candidate gets their confirmation immediately.
    if (app.requisition_id) {
      const scoreUrl = new URL("/api/apply/score", req.url).toString();
      fetch(scoreUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId,
          requisitionId: app.requisition_id,
          candidateId,
        }),
      }).catch((e) => console.error("[apply/submit] score trigger failed:", e));
    }

    return NextResponse.json({
      ok: true,
      applicationId,
      candidateId,
      submittedAt: new Date().toISOString(),
      message: "Application submitted successfully",
    });
  } catch (err) {
    console.error("[/api/apply/submit] error:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 }
    );
  }
}
