import { z } from "zod";

/**
 * Shared validation schemas for the application funnel.
 * Used by:
 *   - The client wizard for live field validation
 *   - API routes for server-side validation
 *   - The Claude resume parser as the structured output schema
 */

// ============================================================================
// Phone, email, address — used across multiple steps
// ============================================================================
const phoneSchema = z
  .string()
  .min(10, "Phone must be at least 10 digits")
  .regex(/^[\d\s\-\(\)\+\.]+$/, "Invalid phone format");

const emailSchema = z.string().email("Please enter a valid email address");

const addressSchema = z.object({
  line1: z.string().min(1, "Street address required"),
  line2: z.string().optional(),
  city: z.string().min(1, "City required"),
  state: z.string().length(2, "Use 2-letter state code"),
  zip: z.string().regex(/^\d{5}(-\d{4})?$/, "Invalid ZIP code"),
});

// ============================================================================
// Step 1 — Resume upload (no form fields, just file)
// ============================================================================
export const resumeUploadResultSchema = z.object({
  storagePath: z.string(),
  fileName: z.string(),
  parsed: z.boolean(),
});

// ============================================================================
// Step 2 — Personal info
// ============================================================================
export const personalInfoSchema = z.object({
  firstName: z.string().min(1, "First name required"),
  middleName: z.string().optional(),
  lastName: z.string().min(1, "Last name required"),
  preferredName: z.string().optional(),

  email: emailSchema,
  phone: phoneSchema,
  alternatePhone: phoneSchema.optional().or(z.literal("")),

  address: addressSchema,

  dateOfBirth: z.string().optional(), // YYYY-MM-DD; we DON'T collect this on apply for fair-hiring reasons, but capture if pre-filled

  // Authorization to work
  authorizedToWorkInUS: z.boolean(),
  requiresSponsorship: z.boolean(),

  // How they heard about us
  referralSource: z.enum([
    "indeed",
    "linkedin",
    "facebook",
    "referral",
    "google_search",
    "career_fair",
    "walk_in",
    "other",
  ]).optional(),
  referrerName: z.string().optional(),

  // Discriminator: are they applying as continuation of a referral?
  hasPreviouslyApplied: z.boolean().default(false),
});

// ============================================================================
// Step 3 — Work history
// ============================================================================
export const workHistoryEntrySchema = z.object({
  employer: z.string().min(1, "Employer name required"),
  jobTitle: z.string().min(1, "Job title required"),
  city: z.string().optional(),
  state: z.string().optional(),

  startDate: z.string().min(1, "Start date required"), // YYYY-MM or YYYY-MM-DD
  endDate: z.string().optional(), // omit if currently employed
  isCurrent: z.boolean().default(false),

  responsibilities: z.string().optional(),
  reasonForLeaving: z.string().optional(),

  supervisorName: z.string().optional(),
  supervisorPhone: z.string().optional(),
  mayContactSupervisor: z.boolean().default(true),
});

export const workHistorySchema = z.object({
  entries: z.array(workHistoryEntrySchema),
  hasEmploymentGaps: z.boolean().default(false),
  gapExplanation: z.string().optional(),
});

// ============================================================================
// Step 4 — Education
// ============================================================================
export const educationEntrySchema = z.object({
  institutionName: z.string().min(1, "School name required"),
  degree: z.string().optional(), // 'High School', 'GED', 'Associates', 'Bachelors', etc.
  fieldOfStudy: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  graduationDate: z.string().optional(), // YYYY-MM
  isCompleted: z.boolean().default(true),
  gpa: z.string().optional(),
});

export const educationSchema = z.object({
  entries: z.array(educationEntrySchema),
  highestLevelCompleted: z.enum([
    "less_than_high_school",
    "high_school",
    "ged",
    "some_college",
    "associates",
    "bachelors",
    "masters",
    "doctorate",
    "other",
  ]),
});

// ============================================================================
// Step 5 — Certifications & licenses
// ============================================================================
export const certificationSchema = z.object({
  name: z.string().min(1, "Certification name required"),
  issuingOrganization: z.string().optional(),
  licenseNumber: z.string().optional(),
  issuedDate: z.string().optional(),
  expirationDate: z.string().optional(),
  state: z.string().optional(),
  isActive: z.boolean().default(true),
});

export const certificationsSchema = z.object({
  entries: z.array(certificationSchema),
  hasNoCertifications: z.boolean().default(false),
});

// ============================================================================
// Step 6 — Documents (uploaded files, validated separately)
// ============================================================================
export const documentsStepSchema = z.object({
  uploadedDocTypes: z.array(z.string()), // e.g. ['drivers_license', 'ssn_card']
});

// ============================================================================
// Step 7 — Background questions (BLH compliance)
// ============================================================================
export const backgroundQuestionsSchema = z.object({
  // Driving — required for most BLH roles (field visits)
  hasValidDriversLicense: z.boolean(),
  driversLicenseState: z.string().length(2).optional(),
  driversLicenseExpires: z.string().optional(),
  hasReliableTransportation: z.boolean(),
  hasAutoInsurance: z.boolean(),

  // Eligibility
  authorizedToWorkInUS: z.boolean(),
  age18OrOlder: z.boolean(),

  // Counties willing to serve — relevant for SP / CCS field roles
  countiesServable: z.array(z.string()).optional(),

  // Pre-employment checks
  willingToCompleteDrugScreen: z.boolean(),
  willingToCompleteBackgroundCheck: z.boolean(),

  // Disclosure (state laws limit how this is asked — we collect with proper context)
  hasBeenConvictedOfCrime: z.boolean(),
  convictionExplanation: z.string().optional(),

  // Voluntary EEO data (collected per federal requirements, not used in screening)
  voluntaryEEO: z.object({
    gender: z.string().optional(),
    ethnicity: z.string().optional(),
    veteranStatus: z.string().optional(),
    disabilityStatus: z.string().optional(),
    prefersNotToDisclose: z.boolean().default(false),
  }).optional(),
});

// ============================================================================
// Step 8 — Sign & submit
// ============================================================================
export const signSubmitSchema = z.object({
  certifyTruthful: z.boolean().refine(v => v === true, {
    message: "You must certify that the information is truthful",
  }),
  authorizeBackgroundCheck: z.boolean().refine(v => v === true, {
    message: "Authorization is required to proceed",
  }),
  acceptTermsAndPrivacy: z.boolean().refine(v => v === true, {
    message: "You must accept the terms and privacy policy",
  }),
  signatureData: z.string().min(1, "Please sign your name"),
  fullLegalName: z.string().min(1, "Type your full legal name"),
});

// ============================================================================
// The full application — what's stored in form_data JSONB
// ============================================================================
export const applicationDataSchema = z.object({
  personal: personalInfoSchema.partial().optional(),
  workHistory: workHistorySchema.partial().optional(),
  education: educationSchema.partial().optional(),
  certifications: certificationsSchema.partial().optional(),
  documents: documentsStepSchema.partial().optional(),
  background: backgroundQuestionsSchema.partial().optional(),
  signature: signSubmitSchema.partial().optional(),
});

export type ApplicationData = z.infer<typeof applicationDataSchema>;
export type PersonalInfo = z.infer<typeof personalInfoSchema>;
export type WorkHistoryEntry = z.infer<typeof workHistoryEntrySchema>;
export type EducationEntry = z.infer<typeof educationEntrySchema>;
export type Certification = z.infer<typeof certificationSchema>;
export type BackgroundQuestions = z.infer<typeof backgroundQuestionsSchema>;

// ============================================================================
// Resume parser output schema — what Claude returns from parse-resume
// ============================================================================
export const parsedResumeSchema = z.object({
  personal: z.object({
    firstName: z.string().nullable(),
    middleName: z.string().nullable(),
    lastName: z.string().nullable(),
    email: z.string().nullable(),
    phone: z.string().nullable(),
    address: z.object({
      line1: z.string().nullable(),
      line2: z.string().nullable(),
      city: z.string().nullable(),
      state: z.string().nullable(),
      zip: z.string().nullable(),
    }).nullable(),
    linkedinUrl: z.string().nullable(),
    portfolioUrl: z.string().nullable(),
  }),

  summary: z.string().nullable(),

  workHistory: z.array(z.object({
    employer: z.string().nullable(),
    jobTitle: z.string().nullable(),
    city: z.string().nullable(),
    state: z.string().nullable(),
    startDate: z.string().nullable(),
    endDate: z.string().nullable(),
    isCurrent: z.boolean(),
    responsibilities: z.string().nullable(),
  })),

  education: z.array(z.object({
    institutionName: z.string().nullable(),
    degree: z.string().nullable(),
    fieldOfStudy: z.string().nullable(),
    city: z.string().nullable(),
    state: z.string().nullable(),
    graduationDate: z.string().nullable(),
    isCompleted: z.boolean(),
  })),

  certifications: z.array(z.object({
    name: z.string().nullable(),
    issuingOrganization: z.string().nullable(),
    licenseNumber: z.string().nullable(),
    issuedDate: z.string().nullable(),
    expirationDate: z.string().nullable(),
    state: z.string().nullable(),
  })),

  skills: z.array(z.string()),
  languages: z.array(z.string()),

  // Computed signals for the recruiter — tuned for case management / coordination roles
  aiSignals: z.object({
    yearsOfRelevantExperience: z.number().nullable(),
    hasCaseManagementExperience: z.boolean(),
    hasHCBSWaiverExperience: z.boolean(),
    hasISPWritingExperience: z.boolean(),
    hasLTSSMarylandExperience: z.boolean(),
    hasIDDPopulationExperience: z.boolean(),
    hasMedicaidExperience: z.boolean(),
    hasBachelorsDegree: z.boolean(),
    bachelorsFieldOfStudy: z.string().nullable(),
    hasManagementExperience: z.boolean(),
    longestTenureMonths: z.number().nullable(),
    jobChangeFrequency: z.enum(["low", "medium", "high"]).nullable(),
    languagesSpoken: z.array(z.string()),
    marylandCountiesServed: z.array(z.string()),
  }),
});

export type ParsedResume = z.infer<typeof parsedResumeSchema>;
