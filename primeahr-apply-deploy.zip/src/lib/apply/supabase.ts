import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Public anon client — safe for the browser, respects RLS.
 * Used in the apply page (client component) for reading role templates.
 */
export function createAnonClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    }
  );
}

/**
 * Service role client — server-only, bypasses RLS.
 * Used in API routes for writing applications, parsing resumes,
 * generating signed URLs, etc.
 *
 * IMPORTANT: Never expose this client to the browser. Only call inside
 * route handlers and server actions.
 */
export function createServiceClient(): SupabaseClient {
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY is not set. Add it to your Vercel env vars."
    );
  }
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    }
  );
}

/**
 * Generate a cryptographically random resume token for save-and-resume links.
 */
export function generateResumeToken(): string {
  const buf = new Uint8Array(32);
  crypto.getRandomValues(buf);
  return Array.from(buf)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/**
 * Standard storage bucket for application files.
 */
export const APPLICATION_BUCKET = "applications";

/**
 * Build a storage path for an application file.
 *   applications/<applicationId>/<docType>/<filename>
 */
export function buildApplicationStoragePath(
  applicationId: string,
  docType: string,
  filename: string
): string {
  const safeFilename = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  return `${applicationId}/${docType}/${Date.now()}_${safeFilename}`;
}
