import Anthropic from "@anthropic-ai/sdk";
import { parsedResumeSchema, type ParsedResume } from "./application-schema";

/**
 * Resume parser powered by Claude.
 *
 * BLH context:
 *   Beatrice Loving Heart is a Maryland CASE MANAGEMENT and CARE COORDINATION
 *   agency. NOT direct care. NOT clinical. We coordinate services under Maryland
 *   Medicaid waiver programs (Community First Choice, DDA HCBS waivers, ECSP, CDS).
 *
 *   Our roles are:
 *   - Support Planner / Senior SP / Team Manager SP — Community First Choice
 *   - Coordinator of Community Services / Lead CCS / Team Manager CCS — DDA
 *   - Plus admin, HR, onboarding, supervisors, and various specialists.
 *
 * Strategy:
 *   1. Send the PDF as a document block to claude-sonnet-4 (vision-enabled).
 *   2. Force structured JSON output via tool-use (`submit_parsed_resume`).
 *   3. Validate the response against parsedResumeSchema (zod).
 */

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const PARSER_MODEL = "claude-sonnet-4-20250514";

const SYSTEM_PROMPT = `You are an expert resume parser for Beatrice Loving Heart (BLH), a Maryland case management and care coordination agency.

BLH serves participants in Maryland Medicaid waiver programs — primarily the Community First Choice (CFC) program and the Developmental Disabilities Administration (DDA) HCBS waivers. BLH does NOT provide direct care. Our staff coordinate services, write Person-Centered Plans / Individual Support Plans, monitor service delivery, and document everything in LTSSMaryland.

Roles you may be parsing resumes for include:
- Support Planner (CFC) and Senior Support Planner, Team Manager / Senior Support Planner
- Coordinator of Community Services (CCS, DDA), Lead CCS, Team Manager / Senior CCS
- Administrative Assistant, Administrative Support Supervisor, Office Manager, Office Coordinator
- Human Resource Manager, Administrative Recruiter, HR Interviewer, Talent Acquisition Manager
- Onboarding Specialist, Intake Coordinator
- Supervisor, Assistant Program Supervisor, Employee Relations Specialist
- Interpreter, In-Office Help Desk Specialist, Data Entry Administrator, Technical Assistance
- Accountant, Book Keeper, Quality Assurance Manager, M&E Specialist

Most of these (especially SP and CCS) require a bachelor's degree, strong documentation skills, and the ability to do field visits across Maryland counties.

Rules:
1. Extract EXACTLY what's on the resume. Do not invent or infer details that aren't there.
2. For missing fields, use null (NOT empty strings).
3. Normalize dates to YYYY-MM format when possible. Use null if a date is ambiguous.
4. Detect current employment from phrases like "Present", "Current", "—", or no end date.
5. For phone numbers, preserve formatting as written but strip extension prefixes.
6. For email, return lowercase.
7. For state, return 2-letter postal codes (Maryland → MD).
8. For skills, focus on case management and coordination skills: documentation, ISP writing, person-centered planning, LTSSMaryland, Medicaid waiver knowledge, case management, behavioral health support, advocacy, communication, etc. NOT clinical skills like medication administration or wound care unless directly relevant.
9. For aiSignals.yearsOfRelevantExperience: sum total years in case management, social work, human services, coordination, advocacy, or related coordination roles. Use null if no relevant experience.
10. For hasIDDPopulationExperience: true if resume mentions work with people who have intellectual or developmental disabilities, autism, I/DD, IDD, DD, mental health, behavioral health, or related populations.
11. For hasHCBSWaiverExperience: true if resume mentions any Medicaid waiver experience — CFC, DDA, ECSP, CDS, HCBS, 1915(c) waivers, Medicaid LTSS, home and community-based services, or similar.
12. For hasISPWritingExperience: true if resume mentions ISP (Individual Support Plan), PCP (Person-Centered Plan), IFSP, IEP, treatment plans, service plans, care plans, or similar planning document creation.
13. For hasLTSSMarylandExperience: true ONLY if resume explicitly mentions LTSSMaryland, LTSS MD, or Maryland's long-term services and support system.
14. For hasBachelorsDegree: true if the candidate has completed (or is in the final year of) a bachelor's degree.
15. For bachelorsFieldOfStudy: the field of the highest-completed degree (e.g. "Social Work", "Psychology", "Human Services", "Sociology", "Education"). Use null if no bachelor's.
16. For marylandCountiesServed: any Maryland counties or jurisdictions the candidate has worked in based on prior employer locations or explicit mentions (e.g. ["Prince George's", "Montgomery", "Baltimore City"]).
17. For languagesSpoken: any languages mentioned beyond English (e.g. ["Spanish", "Amharic", "French", "Tagalog"]).
18. Do not include personal opinions, demographics, age, or photo-derived information.

You will respond by calling the submit_parsed_resume tool. Never respond with plain text — always call the tool.`;

const PARSE_TOOL = {
  name: "submit_parsed_resume",
  description: "Submit the structured resume data after extraction is complete.",
  input_schema: {
    type: "object",
    required: ["personal", "summary", "workHistory", "education", "certifications", "skills", "languages", "aiSignals"],
    properties: {
      personal: {
        type: "object",
        required: ["firstName", "middleName", "lastName", "email", "phone", "address", "linkedinUrl", "portfolioUrl"],
        properties: {
          firstName: { type: ["string", "null"] },
          middleName: { type: ["string", "null"] },
          lastName: { type: ["string", "null"] },
          email: { type: ["string", "null"] },
          phone: { type: ["string", "null"] },
          address: {
            type: ["object", "null"],
            properties: {
              line1: { type: ["string", "null"] },
              line2: { type: ["string", "null"] },
              city: { type: ["string", "null"] },
              state: { type: ["string", "null"] },
              zip: { type: ["string", "null"] },
            },
          },
          linkedinUrl: { type: ["string", "null"] },
          portfolioUrl: { type: ["string", "null"] },
        },
      },
      summary: { type: ["string", "null"], description: "Professional summary section if present" },
      workHistory: {
        type: "array",
        items: {
          type: "object",
          required: ["employer", "jobTitle", "city", "state", "startDate", "endDate", "isCurrent", "responsibilities"],
          properties: {
            employer: { type: ["string", "null"] },
            jobTitle: { type: ["string", "null"] },
            city: { type: ["string", "null"] },
            state: { type: ["string", "null"] },
            startDate: { type: ["string", "null"] },
            endDate: { type: ["string", "null"] },
            isCurrent: { type: "boolean" },
            responsibilities: { type: ["string", "null"] },
          },
        },
      },
      education: {
        type: "array",
        items: {
          type: "object",
          required: ["institutionName", "degree", "fieldOfStudy", "city", "state", "graduationDate", "isCompleted"],
          properties: {
            institutionName: { type: ["string", "null"] },
            degree: { type: ["string", "null"] },
            fieldOfStudy: { type: ["string", "null"] },
            city: { type: ["string", "null"] },
            state: { type: ["string", "null"] },
            graduationDate: { type: ["string", "null"] },
            isCompleted: { type: "boolean" },
          },
        },
      },
      certifications: {
        type: "array",
        items: {
          type: "object",
          required: ["name", "issuingOrganization", "licenseNumber", "issuedDate", "expirationDate", "state"],
          properties: {
            name: { type: ["string", "null"] },
            issuingOrganization: { type: ["string", "null"] },
            licenseNumber: { type: ["string", "null"] },
            issuedDate: { type: ["string", "null"] },
            expirationDate: { type: ["string", "null"] },
            state: { type: ["string", "null"] },
          },
        },
      },
      skills: { type: "array", items: { type: "string" } },
      languages: { type: "array", items: { type: "string" } },
      aiSignals: {
        type: "object",
        required: [
          "yearsOfRelevantExperience",
          "hasCaseManagementExperience",
          "hasHCBSWaiverExperience",
          "hasISPWritingExperience",
          "hasLTSSMarylandExperience",
          "hasIDDPopulationExperience",
          "hasMedicaidExperience",
          "hasBachelorsDegree",
          "bachelorsFieldOfStudy",
          "hasManagementExperience",
          "longestTenureMonths",
          "jobChangeFrequency",
          "languagesSpoken",
          "marylandCountiesServed",
        ],
        properties: {
          yearsOfRelevantExperience: { type: ["number", "null"], description: "Total years in case management, social work, human services, or related coordination roles." },
          hasCaseManagementExperience: { type: "boolean", description: "Prior case management, service coordination, or care coordination experience." },
          hasHCBSWaiverExperience: { type: "boolean", description: "Experience with CFC, DDA, HCBS, 1915(c), or other Medicaid waiver programs." },
          hasISPWritingExperience: { type: "boolean", description: "Experience writing Individual Support Plans, Person-Centered Plans, or similar." },
          hasLTSSMarylandExperience: { type: "boolean", description: "Direct LTSSMaryland system experience (Maryland-specific)." },
          hasIDDPopulationExperience: { type: "boolean", description: "Worked with intellectual / developmental disabilities population." },
          hasMedicaidExperience: { type: "boolean", description: "Any prior Medicaid program experience." },
          hasBachelorsDegree: { type: "boolean", description: "Has completed (or final year of) a bachelor's degree." },
          bachelorsFieldOfStudy: { type: ["string", "null"], description: "Field of highest-completed degree, e.g. 'Social Work'." },
          hasManagementExperience: { type: "boolean", description: "Supervisory or team-lead experience." },
          longestTenureMonths: { type: ["number", "null"], description: "Longest single-job tenure in months." },
          jobChangeFrequency: { type: ["string", "null"], enum: ["low", "medium", "high", null], description: "low: <2 jobs/3yr, medium: 2-4 jobs/3yr, high: 5+ jobs/3yr" },
          languagesSpoken: {
            type: "array",
            items: { type: "string" },
            description: "Languages other than English the candidate speaks.",
          },
          marylandCountiesServed: {
            type: "array",
            items: { type: "string" },
            description: "Maryland counties or jurisdictions where the candidate has prior work experience.",
          },
        },
      },
    },
  },
} as const;

export interface ParseResumeOptions {
  fileBuffer?: Buffer;
  mediaType?: "application/pdf" | "image/png" | "image/jpeg" | "image/webp";
  plainText?: string;
  candidateNameHint?: string;
}

export interface ParseResumeResult {
  parsed: ParsedResume;
  usage: { inputTokens: number; outputTokens: number };
  modelUsed: string;
  rawToolInput: unknown;
}

export async function parseResume(opts: ParseResumeOptions): Promise<ParseResumeResult> {
  if (!opts.fileBuffer && !opts.plainText) {
    throw new Error("parseResume requires either fileBuffer or plainText");
  }

  const contentBlocks: Anthropic.Messages.ContentBlockParam[] = [];

  if (opts.fileBuffer) {
    const base64 = opts.fileBuffer.toString("base64");
    const mediaType = opts.mediaType ?? "application/pdf";

    if (mediaType === "application/pdf") {
      contentBlocks.push({
        type: "document",
        source: { type: "base64", media_type: "application/pdf", data: base64 },
      });
    } else {
      contentBlocks.push({
        type: "image",
        source: { type: "base64", media_type: mediaType, data: base64 },
      });
    }
  }

  if (opts.plainText) {
    contentBlocks.push({ type: "text", text: `Resume text content:\n\n${opts.plainText}` });
  }

  contentBlocks.push({
    type: "text",
    text: opts.candidateNameHint
      ? `The candidate's name is likely "${opts.candidateNameHint}". Parse the resume above and call submit_parsed_resume with the structured data.`
      : `Parse the resume above and call submit_parsed_resume with the structured data.`,
  });

  const response = await anthropic.messages.create({
    model: PARSER_MODEL,
    max_tokens: 4096,
    system: SYSTEM_PROMPT,
    tools: [PARSE_TOOL as unknown as Anthropic.Messages.Tool],
    tool_choice: { type: "tool", name: "submit_parsed_resume" },
    messages: [{ role: "user", content: contentBlocks }],
  });

  const toolUseBlock = response.content.find(
    (b): b is Anthropic.Messages.ToolUseBlock => b.type === "tool_use"
  );

  if (!toolUseBlock) {
    throw new Error("Claude did not return a tool_use block — parsing failed");
  }

  const parsed = parsedResumeSchema.parse(toolUseBlock.input);

  return {
    parsed,
    usage: {
      inputTokens: response.usage.input_tokens,
      outputTokens: response.usage.output_tokens,
    },
    modelUsed: PARSER_MODEL,
    rawToolInput: toolUseBlock.input,
  };
}

/**
 * Generate a concise AI summary of the candidate for the recruiter dashboard.
 */
export async function generateCandidateSummary(parsed: ParsedResume): Promise<string> {
  const response = await anthropic.messages.create({
    model: PARSER_MODEL,
    max_tokens: 400,
    system: `You write concise, factual candidate summaries for HR coordinators at Beatrice Loving Heart, a Maryland case management agency serving CFC and DDA waiver participants.

Each summary is 2-3 sentences. Highlight:
- Relevant case management / coordination experience
- Bachelor's degree and field of study
- HCBS waiver familiarity if any (CFC, DDA, HCBS)
- ISP / Person-Centered Plan writing experience
- Languages beyond English
- Any obvious gaps (no degree, no relevant experience, etc.)

Be specific. Never generic. Do not use marketing language. Do not include demographic information. Do not reference clinical credentials or direct care unless the candidate's prior role required them.`,
    messages: [
      {
        role: "user",
        content: `Generate a 2-3 sentence summary of this candidate for an HR coordinator at BLH:\n\n${JSON.stringify(parsed, null, 2)}`,
      },
    ],
  });

  const textBlock = response.content.find(
    (b): b is Anthropic.Messages.TextBlock => b.type === "text"
  );

  return textBlock?.text.trim() ?? "";
}
